' Crea el acceso directo "VYA ESTUDIO" en el escritorio (sin permisos de administrador)
Set fso = CreateObject("Scripting.FileSystemObject")
carpeta = fso.GetParentFolderName(WScript.ScriptFullName)
Set sh = CreateObject("WScript.Shell")
escritorio = sh.SpecialFolders("Desktop")
Set acc = sh.CreateShortcut(escritorio & "\VYA ESTUDIO.lnk")
acc.TargetPath = sh.ExpandEnvironmentStrings("%SystemRoot%") & "\System32\wscript.exe"
acc.Arguments = """" & carpeta & "\iniciar.vbs"""
acc.WorkingDirectory = carpeta
acc.IconLocation = carpeta & "\icono.ico,0"
acc.Description = "Descargas, karaoke y v�deo profesional"
acc.Save
MsgBox "Listo. Ya tienes VYA ESTUDIO en el escritorio.", 64, "VYA ESTUDIO"
