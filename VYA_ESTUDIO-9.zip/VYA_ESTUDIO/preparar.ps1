﻿param([string]$Base, [switch]$Karaoke)
# VYA ESTUDIO - baja sus herramientas la primera vez (sin ventanas ni permisos de administrador).
$ErrorActionPreference = 'Stop'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$ProgressPreference = 'SilentlyContinue'
$Bin = Join-Path $Base 'bin'
$Py  = Join-Path $Base 'python'
New-Item -ItemType Directory -Force -Path $Bin, $Py | Out-Null
Add-Type -AssemblyName System.IO.Compression.FileSystem

$yt = Join-Path $Bin 'yt-dlp.exe'
if (-not (Test-Path $yt)) {
    Write-Output 'PASO Descargando el motor de descargas...'
    Invoke-WebRequest -UseBasicParsing 'https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp.exe' -OutFile ($yt + '.tmp')
    Move-Item -Force ($yt + '.tmp') $yt
}

$deno = Join-Path $Bin 'deno.exe'
if (-not (Test-Path $deno)) {
    Write-Output 'PASO Descargando el ayudante que pide YouTube (Deno)...'
    $zip = Join-Path $env:TEMP 'vya_deno.zip'
    Invoke-WebRequest -UseBasicParsing 'https://github.com/denoland/deno/releases/latest/download/deno-x86_64-pc-windows-msvc.zip' -OutFile $zip
    $z = [System.IO.Compression.ZipFile]::OpenRead($zip)
    try { foreach ($e in $z.Entries) { if ($e.Name -eq 'deno.exe') { [System.IO.Compression.ZipFileExtensions]::ExtractToFile($e, $deno, $true) } } }
    finally { $z.Dispose() }
    Remove-Item $zip -ErrorAction SilentlyContinue
}

$ff = Join-Path $Bin 'ffmpeg.exe'
if (-not (Test-Path $ff)) {
    Write-Output 'PASO Descargando el motor de vídeo y audio (unos 200 MB, tarda un poco)...'
    $zip = Join-Path $env:TEMP 'vya_ffmpeg.zip'
    Invoke-WebRequest -UseBasicParsing 'https://github.com/yt-dlp/FFmpeg-Builds/releases/download/latest/ffmpeg-master-latest-win64-gpl.zip' -OutFile $zip
    Write-Output 'PASO Preparando el motor de vídeo...'
    $z = [System.IO.Compression.ZipFile]::OpenRead($zip)
    try {
        foreach ($e in $z.Entries) {
            if ($e.Name -eq 'ffmpeg.exe' -or $e.Name -eq 'ffprobe.exe') {
                [System.IO.Compression.ZipFileExtensions]::ExtractToFile($e, (Join-Path $Bin $e.Name), $true)
            }
        }
    } finally { $z.Dispose() }
    Remove-Item $zip -ErrorAction SilentlyContinue
}

$pyExe = Join-Path $Py 'python.exe'
if (-not (Test-Path $pyExe)) {
    Write-Output 'PASO Descargando Python portátil...'
    $zip = Join-Path $env:TEMP 'vya_python.zip'
    Invoke-WebRequest -UseBasicParsing 'https://www.python.org/ftp/python/3.12.10/python-3.12.10-embed-amd64.zip' -OutFile $zip
    [System.IO.Compression.ZipFile]::ExtractToDirectory($zip, $Py)
    Remove-Item $zip -ErrorAction SilentlyContinue
    $pth = Get-ChildItem $Py -Filter 'python*._pth' | Select-Object -First 1
    (Get-Content $pth.FullName) -replace '^#\s*import site', 'import site' | Set-Content $pth.FullName -Encoding ASCII
}

if ($Karaoke) {
    $ErrorActionPreference = 'Continue'   # pip escribe avisos que no son errores
    $sitio = Join-Path $Py 'Lib\site-packages'
    if (-not (Test-Path (Join-Path $sitio 'pip'))) {
        Write-Output 'PASO Instalando el gestor de paquetes...'
        $gp = Join-Path $env:TEMP 'vya_get-pip.py'
        Invoke-WebRequest -UseBasicParsing 'https://bootstrap.pypa.io/get-pip.py' -OutFile $gp
        & $pyExe $gp --no-warn-script-location --disable-pip-version-check 2>&1 | ForEach-Object { "$_" }
        if ($LASTEXITCODE -ne 0) { throw 'No se pudo instalar pip' }
    }
    Write-Output 'PASO Instalando el quitavoces y el oído de la letra (unos 100 MB)...'
    & $pyExe -m pip install --no-warn-script-location --disable-pip-version-check numpy onnxruntime faster-whisper msvc-runtime 2>&1 | ForEach-Object { "$_" }
    if ($LASTEXITCODE -ne 0) { throw 'No se pudieron instalar los paquetes del karaoke' }
}
Write-Output 'PASO Herramientas listas'
