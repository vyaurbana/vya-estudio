"""Quita la voz principal de una canción con un modelo UVR MDX-Net (ONNX), solo con numpy + onnxruntime.

Uso: python separar.py <entrada.wav> <musica.wav> <voz.wav> <modelo.onnx> <dim_f> <n_fft> <compensate>
Imprime líneas "PCT n" con el progreso.
"""
import sys
import wave

import numpy as np
import onnxruntime as ort

HOP = 1024
DIM_T = 256  # 2**8
SR = 44100


def leer_wav(ruta):
    with wave.open(ruta, 'rb') as w:
        assert w.getsampwidth() == 2 and w.getnchannels() == 2 and w.getframerate() == SR, 'wav 44100 estéreo 16 bit'
        datos = np.frombuffer(w.readframes(w.getnframes()), dtype=np.int16)
    return (datos.reshape(-1, 2).T.astype(np.float32) / 32768.0)


def escribir_wav(ruta, x):
    x = np.clip(x, -1.0, 1.0)
    datos = (x.T * 32767.0).astype(np.int16)
    with wave.open(ruta, 'wb') as w:
        w.setnchannels(2); w.setsampwidth(2); w.setframerate(SR)
        w.writeframes(datos.tobytes())


class Stft:
    def __init__(self, n_fft, dim_f):
        self.n_fft = n_fft
        self.dim_f = dim_f
        self.win = (0.5 - 0.5 * np.cos(2 * np.pi * np.arange(n_fft) / n_fft)).astype(np.float32)  # hann periódica

    def directa(self, x):  # x: [canales, muestras] -> [canales*2, dim_f, T]
        p = self.n_fft // 2
        xp = np.pad(x, ((0, 0), (p, p)), mode='reflect')
        n = 1 + (xp.shape[1] - self.n_fft) // HOP
        idx = np.arange(self.n_fft)[None, :] + HOP * np.arange(n)[:, None]
        tramas = xp[:, idx] * self.win  # [c, T, n_fft]
        esp = np.fft.rfft(tramas, axis=-1)[:, :, :self.dim_f]  # [c, T, F]
        esp = np.transpose(esp, (0, 2, 1))  # [c, F, T]
        salida = np.stack([esp.real, esp.imag], axis=1)  # [c, 2, F, T]
        return salida.reshape(-1, self.dim_f, n).astype(np.float32)

    def inversa(self, s, largo):  # s: [canales*2, dim_f, T]
        c = s.shape[0] // 2
        nb = self.n_fft // 2 + 1
        s = s.reshape(c, 2, self.dim_f, -1)
        comp = np.zeros((c, nb, s.shape[-1]), dtype=np.complex64)
        comp[:, :self.dim_f, :] = s[:, 0] + 1j * s[:, 1]
        tramas = np.fft.irfft(np.transpose(comp, (0, 2, 1)), n=self.n_fft, axis=-1) * self.win  # [c, T, n_fft]
        n = tramas.shape[1]
        total = self.n_fft + HOP * (n - 1)
        y = np.zeros((c, total), dtype=np.float32)
        norma = np.zeros(total, dtype=np.float32)
        w2 = self.win ** 2
        for t in range(n):
            y[:, t * HOP:t * HOP + self.n_fft] += tramas[:, t]
            norma[t * HOP:t * HOP + self.n_fft] += w2
        p = self.n_fft // 2
        y = y[:, p:p + largo]
        norma = norma[p:p + largo]
        return y / np.maximum(norma, 1e-8)


def separar(mezcla, modelo, dim_f, n_fft, compensate, avisar=print):
    opciones = ort.SessionOptions()
    sesion = ort.InferenceSession(modelo, opciones, providers=ort.get_available_providers())
    stft = Stft(n_fft, dim_f)
    trim = n_fft // 2
    chunk = HOP * (DIM_T - 1)
    gen = chunk - 2 * trim
    overlap = 0.25

    pico = float(np.abs(mezcla).max()) or 1.0
    mix = mezcla / pico
    pad = gen + trim - (mix.shape[-1] % gen)
    m = np.concatenate([np.zeros((2, trim), np.float32), mix, np.zeros((2, pad), np.float32)], 1)
    res = np.zeros_like(m)
    div = np.zeros_like(m)
    paso = int((1 - overlap) * chunk)
    inicios = list(range(0, m.shape[-1], paso))
    for k, i in enumerate(inicios):
        fin = min(i + chunk, m.shape[-1])
        trozo = m[:, i:fin]
        real = fin - i
        if real < chunk:
            trozo = np.concatenate([trozo, np.zeros((2, chunk - real), np.float32)], 1)
        esp = stft.directa(trozo)
        esp[:, :3, :] = 0
        pred = sesion.run(None, {'input': esp[None]})[0][0]
        ond = stft.inversa(pred, chunk)
        v = np.hanning(real).astype(np.float32)
        res[:, i:fin] += ond[:, :real] * v
        div[:, i:fin] += v
        avisar(f'PCT {int(100 * (k + 1) / len(inicios))}')
    musica = (res / np.maximum(div, 1e-8))[:, trim:trim + mix.shape[-1]] * pico
    voz = mezcla - musica * compensate
    return musica, voz


if __name__ == '__main__':
    ent, sal_m, sal_v, modelo, dim_f, n_fft, comp = sys.argv[1:8]
    x = leer_wav(ent)
    musica, voz = separar(x, modelo, int(dim_f), int(n_fft), float(comp), lambda s: print(s, flush=True))
    escribir_wav(sal_m, musica)
    escribir_wav(sal_v, voz)
    print('LISTO', flush=True)
