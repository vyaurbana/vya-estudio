"""VYA ESTUDIO - motor de vídeo profesional (montaje).

  python montaje.py <trabajo.json> <bin_ffmpeg>

trabajo.json:
{
  "salida": "C:/.../mi video.mp4",
  "formato": "horizontal" | "4k" | "vertical" | "cuadrado",
  "transicion": "fundido" | "deslizar" | "zoom" | "ninguna",
  "titulo": "Texto al principio", "subtitulo": "", "final": "Texto del final",
  "musica": "C:/.../cancion.mp3" o "", "volumen_musica": 0.35, "sonido_original": true,
  "segundos_foto": 4,
  "clips": [ {"ruta": "...", "desde": 0, "hasta": 0}, ... ]   (hasta 0 = hasta el final)
}
Imprime "PASO texto" y "PCT n".
"""
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile

OCULTO = 0x08000000 if os.name == 'nt' else 0
FPS = 30
TRANS = 0.8
FOTOS = ('.jpg', '.jpeg', '.png', '.bmp', '.webp', '.heic', '.tif', '.tiff')
FORMATOS = {'horizontal': (1920, 1080), '4k': (3840, 2160), 'vertical': (1080, 1920), 'cuadrado': (1080, 1080)}
XFADE = {'fundido': 'fade', 'deslizar': 'slideleft', 'zoom': 'zoomin', 'ninguna': None}


def paso(t):
    print('PASO ' + t, flush=True)


def pct(n):
    print(f'PCT {int(max(0, min(100, n)))}', flush=True)


def ff(binff, n):
    exe = os.path.join(binff, n + ('.exe' if os.name == 'nt' else ''))
    return exe if os.path.exists(exe) else n


def correr(cmd, cwd=None, dur=None, base=0.0, peso=100.0):
    p = subprocess.Popen(cmd, cwd=cwd, stderr=subprocess.PIPE, stdout=subprocess.DEVNULL, creationflags=OCULTO)
    buf, cola = b'', []
    while True:
        c = p.stderr.read(1)
        if not c:
            break
        if c in b'\r\n':
            m = re.search(rb'time=(\d+):(\d+):([\d.]+)', buf)
            if m and dur:
                s = int(m.group(1)) * 3600 + int(m.group(2)) * 60 + float(m.group(3))
                pct(base + peso * min(1.0, s / dur))
            elif buf.strip():
                cola = (cola + [buf])[-12:]
            buf = b''
        else:
            buf += c
    if p.wait() != 0:
        raise RuntimeError(b' | '.join(cola).decode('utf-8', 'replace')[-800:])


def info(binff, ruta):
    out = subprocess.run([ff(binff, 'ffprobe'), '-v', 'error', '-show_entries', 'format=duration:stream=codec_type',
                          '-of', 'json', ruta], capture_output=True, creationflags=OCULTO).stdout
    d = json.loads(out or b'{}')
    tipos = [s.get('codec_type') for s in d.get('streams', [])]
    return float(d.get('format', {}).get('duration') or 0), 'audio' in tipos


def fondo_borroso(w, h, entrada='[0:v]'):
    return (f'{entrada}split[a][b];[a]scale={w}:{h}:force_original_aspect_ratio=increase,crop={w}:{h},'
            f'boxblur=40:2,eq=brightness=-0.12[bg];[b]scale={w}:{h}:force_original_aspect_ratio=decrease[fg];'
            f'[bg][fg]overlay=(W-w)/2:(H-h)/2,setsar=1')


def preparar_clip(binff, clip, w, h, seg_foto, destino, con_sonido):
    ruta = clip['ruta']
    es_foto = os.path.splitext(ruta)[1].lower() in FOTOS
    comun = ['-c:v', 'libx264', '-preset', 'veryfast', '-crf', '18', '-pix_fmt', 'yuv420p', '-r', str(FPS),
             '-c:a', 'aac', '-b:a', '192k', '-ar', '48000', '-ac', '2']
    if es_foto:
        dur = float(clip.get('hasta') or 0) or seg_foto
        n = int(dur * FPS)
        W, H = int(w * 1.5) // 2 * 2, int(h * 1.5) // 2 * 2
        filtro = (fondo_borroso(W, H) + f',zoompan=z=\'min(zoom+0.0007,1.10)\':x=\'iw/2-(iw/zoom/2)\':'
                  f'y=\'ih/2-(ih/zoom/2)\':d={n}:s={w}x{h}:fps={FPS},format=yuv420p[v]')
        cmd = [ff(binff, 'ffmpeg'), '-y', '-v', 'error', '-stats', '-loop', '1', '-framerate', str(FPS), '-t', str(dur),
               '-i', ruta, '-f', 'lavfi', '-t', str(dur), '-i', 'anullsrc=r=48000:cl=stereo',
               '-filter_complex', filtro, '-map', '[v]', '-map', '1:a', '-t', str(dur)] + comun + [destino]
        return cmd, dur
    total, tiene_audio = info(binff, ruta)
    desde = float(clip.get('desde') or 0)
    hasta = float(clip.get('hasta') or 0) or total
    dur = max(0.5, hasta - desde)
    filtro = fondo_borroso(w, h) + f',fps={FPS},format=yuv420p[v]'
    entradas = ['-ss', str(desde), '-t', str(dur), '-i', ruta]
    if tiene_audio and con_sonido:
        filtro += ';[0:a]aformat=sample_rates=48000:channel_layouts=stereo[a]'
        mapa = ['-map', '[v]', '-map', '[a]']
    else:
        entradas += ['-f', 'lavfi', '-t', str(dur), '-i', 'anullsrc=r=48000:cl=stereo']
        mapa = ['-map', '[v]', '-map', '1:a']
    cmd = [ff(binff, 'ffmpeg'), '-y', '-v', 'error', '-stats'] + entradas + ['-filter_complex', filtro] + mapa + \
          ['-t', str(dur)] + comun + [destino]
    return cmd, dur


def ts(s):
    s = max(0.0, s)
    return f'{int(s // 3600)}:{int(s % 3600 // 60):02d}:{s % 60:05.2f}'


def esc(t):
    return (t or '').replace('\\', '').replace('{', '(').replace('}', ')').replace('\n', '\\N')


def hacer_ass(ruta, w, h, titulo, subtitulo, final, total):
    g = h / 1080 if w >= h else w / 1080
    t1, t2, t3 = int(110 * g), int(54 * g), int(40 * g)
    oro, blanco = '&H005AAFD4', '&H00F5F2EA'
    ev = []
    if titulo:
        ev.append(f'Dialogue: 0,{ts(0.4)},{ts(4.2)},Titulo,,0,0,0,,{{\\fad(600,600)}}{esc(titulo)}')
        if subtitulo:
            ev.append(f'Dialogue: 0,{ts(0.9)},{ts(4.2)},Sub,,0,0,0,,{{\\fad(600,600)}}{esc(subtitulo)}')
    if final:
        ev.append(f'Dialogue: 0,{ts(total - 3.6)},{ts(total)},Titulo,,0,0,0,,{{\\fad(700,500)}}{esc(final)}')
    ev.append(f'Dialogue: 0,{ts(0)},{ts(total)},Marca,,0,0,0,,{{\\alpha&H60&}}VYA')
    with open(ruta, 'w', encoding='utf-8-sig') as f:
        f.write(f"""[Script Info]
ScriptType: v4.00+
PlayResX: {w}
PlayResY: {h}
WrapStyle: 0

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Titulo,Arial,{t1},{oro},{oro},&H00000000,&H80000000,-1,0,0,0,100,100,{int(3 * g)},0,1,{int(4 * g)},{int(3 * g)},5,{int(80 * g)},{int(80 * g)},0,1
Style: Sub,Arial,{t2},{blanco},{blanco},&H00000000,&H80000000,0,0,0,0,100,100,{int(2 * g)},0,1,{int(3 * g)},{int(2 * g)},2,{int(80 * g)},{int(80 * g)},{int(h * 0.33)},1
Style: Marca,Arial,{t3},{oro},{oro},&H00000000,&H00000000,-1,0,0,0,100,100,{int(6 * g)},0,1,{int(2 * g)},0,9,{int(40 * g)},{int(40 * g)},{int(36 * g)},1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
""" + '\n'.join(ev) + '\n')


def montar(trabajo, binff):
    w, h = FORMATOS.get(trabajo.get('formato', 'horizontal'), FORMATOS['horizontal'])
    clips = [c for c in trabajo.get('clips', []) if os.path.exists(c.get('ruta', ''))]
    if not clips:
        raise RuntimeError('No hay clips ni fotos para montar')
    tmp = tempfile.mkdtemp(prefix='vya_montaje_')
    try:
        partes, durs = [], []
        con_sonido = trabajo.get('sonido_original', True)
        for i, c in enumerate(clips):
            paso(f'Preparando clip {i + 1} de {len(clips)}…')
            destino = os.path.join(tmp, f'p{i:03d}.mp4')
            cmd, dur = preparar_clip(binff, c, w, h, float(trabajo.get('segundos_foto') or 4), destino, con_sonido)
            correr(cmd, dur=dur, base=60 * i / len(clips), peso=60 / len(clips))
            partes.append(destino)
            durs.append(dur)
        if trabajo.get('final'):  # cierre en negro para el texto final
            destino = os.path.join(tmp, 'cierre.mp4')
            correr([ff(binff, 'ffmpeg'), '-y', '-v', 'error', '-f', 'lavfi', '-i', f'color=c=0x0B0B0B:s={w}x{h}:r={FPS}:d=4',
                    '-f', 'lavfi', '-t', '4', '-i', 'anullsrc=r=48000:cl=stereo', '-shortest', '-c:v', 'libx264',
                    '-pix_fmt', 'yuv420p', '-c:a', 'aac', '-ar', '48000', '-ac', '2', destino])
            partes.append(destino)
            durs.append(4.0)

        paso('Uniendo con transiciones…')
        efecto = XFADE.get(trabajo.get('transicion', 'fundido'), 'fade')
        t = TRANS if efecto else 0.0
        t = min(t, min(durs) / 2.5) if len(durs) > 1 else 0.0
        entradas, fc = [], []
        for p in partes:
            entradas += ['-i', p]
        total = sum(durs) - t * (len(durs) - 1)
        if len(partes) == 1:
            fc.append('[0:v]null[vx];[0:a]anull[ax]')
        elif efecto:
            prev_v, prev_a, acum = '[0:v]', '[0:a]', durs[0]
            for i in range(1, len(partes)):
                off = acum - t * i
                nv, na = f'[v{i}]', f'[a{i}]'
                fc.append(f'{prev_v}[{i}:v]xfade=transition={efecto}:duration={t:.2f}:offset={off:.3f}{nv}')
                fc.append(f'{prev_a}[{i}:a]acrossfade=d={t:.2f}{na}')
                prev_v, prev_a = nv, na
                acum += durs[i]
            fc.append(f'{prev_v}null[vx];{prev_a}anull[ax]')
        else:
            pares = ''.join(f'[{i}:v][{i}:a]' for i in range(len(partes)))
            fc.append(f'{pares}concat=n={len(partes)}:v=1:a=1[vx][ax]')

        hacer_ass(os.path.join(tmp, 'textos.ass'), w, h, trabajo.get('titulo'), trabajo.get('subtitulo'),
                  trabajo.get('final'), total)
        fc.append('[vx]subtitles=textos.ass[v]')

        musica = trabajo.get('musica') or ''
        if musica and os.path.exists(musica):
            entradas += ['-stream_loop', '-1', '-i', musica]
            k = len(partes)
            vol = float(trabajo.get('volumen_musica', 0.35))
            fc.append(f'[{k}:a]aformat=sample_rates=48000:channel_layouts=stereo,volume={vol:.2f},'
                      f'afade=t=in:d=1.5,afade=t=out:st={max(0.0, total - 3):.2f}:d=3,atrim=0:{total:.2f}[mus]')
            if con_sonido:  # la música baja sola cuando se habla
                fc.append('[ax]asplit[ax1][ax2];[mus][ax1]sidechaincompress=threshold=0.03:ratio=8:attack=20:release=400[musd];'
                          '[ax2][musd]amix=inputs=2:duration=first:normalize=0,loudnorm=I=-14:TP=-1.5[a]')
            else:
                fc.append('[mus]loudnorm=I=-14:TP=-1.5[a]')
        else:
            fc.append('[ax]loudnorm=I=-14:TP=-1.5[a]')

        salida = os.path.abspath(trabajo['salida'])
        os.makedirs(os.path.dirname(salida), exist_ok=True)
        tmp_out = os.path.join(tmp, 'final.mp4')
        paso('Creando el vídeo final…')
        correr([ff(binff, 'ffmpeg'), '-y', '-v', 'error', '-stats'] + entradas +
               ['-filter_complex', ';'.join(fc), '-map', '[v]', '-map', '[a]', '-c:v', 'libx264', '-preset', 'medium',
                '-crf', '18', '-pix_fmt', 'yuv420p', '-r', str(FPS), '-c:a', 'aac', '-b:a', '256k', '-ar', '48000',
                '-t', f'{total:.3f}', '-movflags', '+faststart', 'final.mp4'],
               cwd=tmp, dur=total, base=60, peso=40)
        shutil.move(tmp_out, salida)
        print('ARCHIVO ' + salida, flush=True)
        paso('¡Vídeo terminado!')
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


if __name__ == '__main__':
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except Exception:
        pass
    try:
        with open(sys.argv[1], encoding='utf-8-sig') as f:
            montar(json.load(f), sys.argv[2])
    except Exception as e:  # noqa: BLE001
        print('ERROR ' + str(e).replace('\n', ' ')[:600], flush=True)
        sys.exit(1)
