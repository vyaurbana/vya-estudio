﻿# VYA ESTUDIO - se actualiza solo al abrirlo (sin ventanas ni permisos de administrador).
# Mira version.json en internet; si hay versión nueva, baja el zip, comprueba su huella y cambia los archivos del programa.
$ErrorActionPreference = 'Stop'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$ProgressPreference = 'SilentlyContinue'
$Base = Split-Path -Parent $MyInvocation.MyCommand.Path
$URL  = 'https://raw.githubusercontent.com/vyaurbana/vya-estudio/main/version.json'
try {
    $local = 0
    $vf = Join-Path $Base 'version.txt'
    if (Test-Path $vf) { $local = [int]((Get-Content $vf -Raw).Trim()) }
    $v = Invoke-RestMethod -UseBasicParsing -Uri ($URL + '?t=' + [DateTime]::Now.Ticks) -TimeoutSec 6
    if ([int]$v.version -le $local) { exit 0 }
    $zip = Join-Path $env:TEMP 'vya_estudio_nuevo.zip'
    Invoke-WebRequest -UseBasicParsing -Uri $v.zip -OutFile $zip -TimeoutSec 120
    $huella = (Get-FileHash $zip -Algorithm SHA256).Hash
    if ($huella -ne ([string]$v.sha256).ToUpper()) { Remove-Item $zip; exit 0 }
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    $z = [System.IO.Compression.ZipFile]::OpenRead($zip)
    try {
        foreach ($e in $z.Entries) {
            if (-not $e.Name) { continue }
            $rel = $e.FullName -replace '^[^/]+/', ''          # quita la carpeta VYA_ESTUDIO/ del zip
            if ($rel -match '^(bin|python|modelos)/' -or $rel -match '\.\.') { continue }
            $dest = Join-Path $Base ($rel -replace '/', '\')
            New-Item -ItemType Directory -Force -Path (Split-Path $dest) | Out-Null
            [System.IO.Compression.ZipFileExtensions]::ExtractToFile($e, $dest + '.nuevo', $true)
            Move-Item -Force ($dest + '.nuevo') $dest
        }
    } finally { $z.Dispose() }
    Remove-Item $zip -ErrorAction SilentlyContinue
    Set-Content -Path $vf -Value ([string]$v.version) -Encoding ASCII
} catch { exit 0 }   # sin internet o fallo: abre la versión que ya hay
