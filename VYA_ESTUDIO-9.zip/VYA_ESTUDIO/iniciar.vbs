' Abre VYA ESTUDIO sin ventana negra; antes mira si hay versi�n nueva y se actualiza sola
Set fso = CreateObject("Scripting.FileSystemObject")
carpeta = fso.GetParentFolderName(WScript.ScriptFullName)
Set sh = CreateObject("WScript.Shell")
sh.CurrentDirectory = carpeta
If fso.FileExists(carpeta & "\actualizar.ps1") Then
    sh.Run "powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File """ & carpeta & "\actualizar.ps1""", 0, True
End If
sh.Run "powershell.exe -NoProfile -ExecutionPolicy Bypass -STA -WindowStyle Hidden -File """ & carpeta & "\VYA_ESTUDIO.ps1""", 0, False
