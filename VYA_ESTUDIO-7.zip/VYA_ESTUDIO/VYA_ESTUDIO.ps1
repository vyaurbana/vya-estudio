﻿# VYA ESTUDIO - todo en uno: descargar vídeo/MP3, crear karaokes y montar vídeos profesionales.
# Herramientas libres: yt-dlp, FFmpeg, Python portátil, quitavoces UVR y Whisper. Se las baja solo la primera vez.

Add-Type -AssemblyName System.Windows.Forms
# Para que la barra de tareas muestre el icono de VYA ESTUDIO y no el de PowerShell
try {
    Add-Type -Namespace VYA -Name Barra -MemberDefinition '[DllImport("shell32.dll", CharSet = CharSet.Unicode)] public static extern int SetCurrentProcessExplicitAppUserModelID(string id);'
    [void][VYA.Barra]::SetCurrentProcessExplicitAppUserModelID('VYAURBANA.VYAESTUDIO')
} catch {}
Add-Type -AssemblyName System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$Inv = [System.Globalization.CultureInfo]::InvariantCulture

$Base    = Split-Path -Parent $MyInvocation.MyCommand.Path
$Bin     = Join-Path $Base 'bin'
$Motor   = Join-Path $Base 'motor'
$Modelos = Join-Path $Base 'modelos'
$PyExe   = Join-Path $Base 'python\python.exe'
$YtDlp   = Join-Path $Bin 'yt-dlp.exe'
$Ffmpeg  = Join-Path $Bin 'ffmpeg.exe'
$Deno    = Join-Path $Bin 'deno.exe'
$Ajustes = Join-Path $Base 'ajustes.txt'
New-Item -ItemType Directory -Force -Path $Bin, $Modelos | Out-Null

# ---------- colores y letras ----------
$Negro  = [System.Drawing.Color]::FromArgb(11,11,11)
$Panel  = [System.Drawing.Color]::FromArgb(30,30,30)
$Caja   = [System.Drawing.Color]::FromArgb(44,44,44)
$Oro    = [System.Drawing.Color]::FromArgb(212,175,90)
$Blanco = [System.Drawing.Color]::FromArgb(245,242,234)
$Gris   = [System.Drawing.Color]::FromArgb(185,178,165)
$Rojo   = [System.Drawing.Color]::FromArgb(240,110,90)
$Fuente       = New-Object System.Drawing.Font('Segoe UI', 12)
$FuenteBold   = New-Object System.Drawing.Font('Segoe UI', 12, [System.Drawing.FontStyle]::Bold)
$FuenteGrande = New-Object System.Drawing.Font('Segoe UI', 14, [System.Drawing.FontStyle]::Bold)
$FuenteTitulo = New-Object System.Drawing.Font('Segoe UI', 24, [System.Drawing.FontStyle]::Bold)

# ---------- carpeta donde se guarda todo (la elige el usuario y se recuerda) ----------
# Carpeta propia con 4 carpetas dentro (fuera de Vídeos/Documentos/Escritorio, que Windows puede bloquear)
$script:Destino = 'C:\VYA ESTUDIO ARCHIVOS'
try { New-Item -ItemType Directory -Force -Path $script:Destino -ErrorAction Stop | Out-Null }
catch { $script:Destino = Join-Path $env:USERPROFILE 'VYA ESTUDIO ARCHIVOS' }
# Si hay cosas en las carpetas de antes (dentro del usuario o en F:), se pasan solas a la nueva
foreach ($vieja in @((Join-Path $env:USERPROFILE 'VYA ESTUDIO ARCHIVOS'), 'F:\VYA ESTUDIO ARCHIVOS')) {
    if ($vieja -ne $script:Destino -and (Test-Path -LiteralPath $vieja)) {
        try {
            Get-ChildItem -LiteralPath $vieja -Directory | ForEach-Object {
                $dst = Join-Path $script:Destino $_.Name
                New-Item -ItemType Directory -Force -Path $dst | Out-Null
                Get-ChildItem -LiteralPath $_.FullName -Force | Move-Item -Destination $dst -Force -ErrorAction SilentlyContinue
            }
            if (-not (Get-ChildItem -LiteralPath $vieja -Recurse -File -Force)) { Remove-Item -LiteralPath $vieja -Recurse -Force -ErrorAction SilentlyContinue }
        } catch {}
    }
}
$DirGenerados  = Join-Path $script:Destino 'VIDEOS GENERADOS'
$DirVideos     = Join-Path $script:Destino 'VIDEOS DESCARGADOS'
$DirMp3        = Join-Path $script:Destino 'MP3 DESCARGADOS'
$DirKaraokes   = Join-Path $script:Destino 'KARAOKES'
New-Item -ItemType Directory -Force -Path $DirGenerados, $DirVideos, $DirMp3, $DirKaraokes | Out-Null

# ---------- ventana ----------
$f = New-Object System.Windows.Forms.Form
$f.Text = 'VYA ESTUDIO'
$f.Size = New-Object System.Drawing.Size(1320, 940)
$f.MinimumSize = New-Object System.Drawing.Size(900, 560)
$f.StartPosition = 'CenterScreen'
$f.WindowState = 'Maximized'
$f.BackColor = $Negro; $f.ForeColor = $Blanco; $f.Font = $Fuente
$ico = Join-Path $Base 'icono.ico'
if (Test-Path $ico) { $f.Icon = New-Object System.Drawing.Icon($ico) }

function Pos($c, $x, $y, $w, $h) {
    $c.Location = New-Object System.Drawing.Point($x, $y)
    $c.Size = New-Object System.Drawing.Size($w, $h)
}
function Nuevo-Label($padre, $texto, $x, $y, $w, $h, $font, $color) {
    $l = New-Object System.Windows.Forms.Label
    $l.Text = $texto; Pos $l $x $y $w $h; $l.Font = $font; $l.ForeColor = $color; $l.BackColor = [System.Drawing.Color]::Transparent
    $padre.Controls.Add($l); return $l
}
function Nuevo-Boton($padre, $texto, $x, $y, $w, $h, $principal) {
    $b = New-Object System.Windows.Forms.Button
    $b.Text = $texto; Pos $b $x $y $w $h; $b.FlatStyle = 'Flat'; $b.Font = $FuenteBold
    $b.Cursor = [System.Windows.Forms.Cursors]::Hand
    if ($principal) { $b.BackColor = $Oro; $b.ForeColor = $Negro; $b.FlatAppearance.BorderSize = 0 }
    else { $b.BackColor = $Panel; $b.ForeColor = $Oro; $b.FlatAppearance.BorderColor = $Oro; $b.FlatAppearance.BorderSize = 1 }
    $padre.Controls.Add($b); return $b
}
function Nueva-Caja($padre, $x, $y, $w, $h, $multi) {
    $t = New-Object System.Windows.Forms.TextBox
    $t.Multiline = [bool]$multi; Pos $t $x $y $w $h
    $t.BackColor = $Caja; $t.ForeColor = $Blanco; $t.BorderStyle = 'FixedSingle'
    $t.Font = New-Object System.Drawing.Font('Segoe UI', 13)
    if ($multi) { $t.ScrollBars = 'Vertical'; $t.AcceptsReturn = $true }
    $padre.Controls.Add($t); return $t
}
function Nuevo-Combo($padre, $x, $y, $w, $opciones) {
    $c = New-Object System.Windows.Forms.ComboBox
    $c.DropDownStyle = 'DropDownList'; Pos $c $x $y $w 34
    $c.BackColor = $Caja; $c.ForeColor = $Blanco; $c.FlatStyle = 'Flat'; $c.Font = $Fuente
    foreach ($o in $opciones) { [void]$c.Items.Add($o) }
    $c.SelectedIndex = 0
    $padre.Controls.Add($c); return $c
}

# ---------- cabecera ----------
$cab = New-Object System.Windows.Forms.Panel
$cab.Dock = 'Top'; $cab.Height = 122; $cab.BackColor = $Negro
$f.Controls.Add($cab)
Nuevo-Label $cab 'VYA ESTUDIO' 30 16 360 50 $FuenteTitulo $Oro | Out-Null
$tabDesc = Nuevo-Boton $cab 'DESCARGAR' 420 18 250 52 $false
$tabKara = Nuevo-Boton $cab 'KARAOKE' 684 18 250 52 $false
$tabVid  = Nuevo-Boton $cab 'VÍDEO PRO' 948 18 250 52 $false

$lblDest = Nuevo-Label $cab ('Todo se guarda en: ' + $script:Destino) 32 80 960 30 $Fuente $Gris
$lblDest.Anchor = 'Top,Left,Right'
$btnAbrir   = Nuevo-Boton $cab 'Abrir carpeta' 1012 74 186 40 $false
$btnAbrir.Anchor = 'Top,Right'

$linea = New-Object System.Windows.Forms.Panel
Pos $linea 30 118 1200 2; $linea.BackColor = $Oro; $linea.Anchor = 'Top,Left,Right'
$cab.Controls.Add($linea)

# ---------- parte de abajo: progreso y detalle (uno por sección, trabajan a la vez) ----------
$pie = New-Object System.Windows.Forms.Panel
$pie.Dock = 'Bottom'; $pie.Height = 160; $pie.BackColor = $Negro
$f.Controls.Add($pie)
$btnDetalle = Nuevo-Boton $pie 'Ver detalle completo' 1000 36 232 38 $false
$btnDetalle.Anchor = 'Top,Right'
$Jobs = @{}
foreach ($k in @('desc', 'kara', 'vid')) {
    $b = New-Object System.Windows.Forms.ProgressBar
    Pos $b 32 8 1200 24; $b.Anchor = 'Top,Left,Right'; $pie.Controls.Add($b)
    $l = Nuevo-Label $pie 'Listo.' 32 38 960 34 $FuenteGrande $Oro
    $l.Anchor = 'Top,Left,Right'
    $t = New-Object System.Windows.Forms.TextBox
    $t.Multiline = $true; $t.ReadOnly = $true; $t.ScrollBars = 'Both'; $t.WordWrap = $false
    Pos $t 32 80 1200 72
    $t.BackColor = $Panel; $t.ForeColor = $Blanco; $t.BorderStyle = 'FixedSingle'
    $t.Font = New-Object System.Drawing.Font('Consolas', 11)
    $t.Anchor = 'Top,Bottom,Left,Right'
    $pie.Controls.Add($t)
    $Jobs[$k] = @{ barra = $b; lbl = $l; log = $t; proc = $null; fn = $null; despues = $null
                   logFile = (Join-Path $env:TEMP ('vya_estudio_' + $k + '.txt')); pos = 0; resto = ''
                   archivo = $null; error = $null; botones = @() }
}
# Variables "de la sección en curso" (las usan las acciones)
$script:JK = 'desc'
function Usar($k) {
    $script:JK = $k; $j = $Jobs[$k]
    $script:barra = $j.barra; $script:lblEstado = $j.lbl; $script:log = $j.log
    $script:ultimoArchivo = $j.archivo; $script:ultimoError = $j.error
}
Usar 'desc'
$lblEstado.Text = 'Preparando…'

# ---------- paneles de cada sección ----------
function Nuevo-Panel($alto) {
    $p = New-Object System.Windows.Forms.Panel
    $p.Dock = 'Fill'; $p.AutoScroll = $true; $p.BackColor = $Negro
    $p.Padding = New-Object System.Windows.Forms.Padding(30, 8, 30, 0)
    $p.AutoScrollMinSize = New-Object System.Drawing.Size(1290, $alto)
    $f.Controls.Add($p); $p.BringToFront(); return $p
}
$pDesc = Nuevo-Panel 300; $pKara = Nuevo-Panel 590; $pVid = Nuevo-Panel 590
function Mover-Dentro($p) { foreach ($c in $p.Controls) { $c.Left += 30 } }

# ===== DESCARGAR =====
Nuevo-Label $pDesc 'Pega el enlace del vídeo (YouTube y otras webs) y elige: vídeo o solo música (MP3).' 2 4 1100 30 $Fuente $Gris | Out-Null
$txtUrl = Nueva-Caja $pDesc 2 42 1236 38 $false
$txtUrl.Font = New-Object System.Drawing.Font('Segoe UI', 15); $txtUrl.Anchor = 'Top,Left,Right'
$btnPegar = Nuevo-Boton $pDesc 'Pegar enlace' 2 98 220 60 $false
$btnVideo = Nuevo-Boton $pDesc 'DESCARGAR VÍDEO' 238 98 330 60 $true
$btnMp3   = Nuevo-Boton $pDesc 'DESCARGAR MP3' 584 98 330 60 $true
Nuevo-Label $pDesc '¿Ya tienes el vídeo en el PC y solo quieres la música?' 2 176 700 30 $Fuente $Gris | Out-Null
$btnConvertir = Nuevo-Boton $pDesc 'Convertir un vídeo del PC a MP3' 2 210 420 56 $false


# ===== KARAOKE =====
Nuevo-Label $pKara 'Añade canciones a la cola (del PC o enlaces) y pulsa CREAR KARAOKES: se hacen solas, una detrás de otra.' 2 4 1230 30 $Fuente $Gris | Out-Null
$btnKElegir = Nuevo-Boton $pKara 'Añadir canciones del PC' 2 42 330 56 $false
Nuevo-Label $pKara 'o enlace:' 346 56 90 30 $Fuente $Gris | Out-Null
$txtKUrl = Nueva-Caja $pKara 438 50 500 38 $false
$btnKPegar = Nuevo-Boton $pKara 'Pegar enlace y añadir' 952 42 286 56 $false
Nuevo-Label $pKara 'Idioma de la canción:' 2 112 200 28 $FuenteBold $Oro | Out-Null
$cmbIdioma = Nuevo-Combo $pKara 204 108 248 @('Español', 'Inglés', 'Otro (que lo adivine)')
$rbRapida = New-Object System.Windows.Forms.RadioButton
$rbRapida.Text = 'Letra rápida'; Pos $rbRapida 2 150 190 32; $rbRapida.Checked = $true; $rbRapida.ForeColor = $Blanco
$rbPrecisa = New-Object System.Windows.Forms.RadioButton
$rbPrecisa.Text = 'Letra precisa (más lenta, mejor para flamenco)'; Pos $rbPrecisa 200 150 560 32; $rbPrecisa.ForeColor = $Blanco
$pKara.Controls.Add($rbRapida); $pKara.Controls.Add($rbPrecisa)
$btnKCrear = Nuevo-Boton $pKara 'CREAR KARAOKES' 858 116 380 66 $true
$btnKCrear.Font = $FuenteGrande
Nuevo-Label $pKara 'Letra (corrígela aquí, una frase por línea):' 2 206 760 28 $FuenteBold $Oro | Out-Null
$txtLetra = Nueva-Caja $pKara 2 238 760 262 $true
$txtLetra.Anchor = 'Top,Bottom,Left'
Nuevo-Label $pKara 'Cola de karaokes (doble clic en uno hecho para verlo):' 780 206 458 28 $FuenteBold $Oro | Out-Null
$lstCola = New-Object System.Windows.Forms.ListBox
Pos $lstCola 780 238 458 206; $lstCola.BackColor = $Caja; $lstCola.ForeColor = $Blanco; $lstCola.BorderStyle = 'FixedSingle'
$lstCola.Font = New-Object System.Drawing.Font('Segoe UI', 11); $lstCola.HorizontalScrollbar = $true
$lstCola.Anchor = 'Top,Bottom,Left'
$pKara.Controls.Add($lstCola)
$btnKQuitar = Nuevo-Boton $pKara 'Quitar de la cola' 780 452 225 48 $false
$btnKVaciar = Nuevo-Boton $pKara 'Vaciar cola' 1013 452 225 48 $false
foreach ($b in @($btnKQuitar, $btnKVaciar)) { $b.Anchor = 'Bottom,Left' }
$btnKRehacer = Nuevo-Boton $pKara 'GUARDAR LETRA Y REHACER VÍDEO' 2 514 390 58 $true
$btnKVer     = Nuevo-Boton $pKara 'Ver el karaoke' 402 514 200 58 $false
$btnKCarpeta = Nuevo-Boton $pKara 'Abrir carpeta' 612 514 200 58 $false
$btnKOtro    = Nuevo-Boton $pKara 'Abrir otro karaoke' 822 514 220 58 $false
$btnKLimpiar = Nuevo-Boton $pKara 'Limpiar letra' 1052 514 186 58 $false
foreach ($b in @($btnKRehacer, $btnKVer, $btnKCarpeta, $btnKOtro, $btnKLimpiar)) { $b.Anchor = 'Bottom,Left' }

# ===== VÍDEO PRO =====
Nuevo-Label $pVid 'Vídeos y fotos, en el orden en que salen:' 2 4 600 30 $FuenteBold $Oro | Out-Null
$lista = New-Object System.Windows.Forms.ListBox
Pos $lista 2 38 600 300; $lista.BackColor = $Caja; $lista.ForeColor = $Blanco; $lista.BorderStyle = 'FixedSingle'
$lista.Font = New-Object System.Drawing.Font('Segoe UI', 12); $lista.HorizontalScrollbar = $true
$lista.Anchor = 'Top,Bottom,Left'
$pVid.Controls.Add($lista)
$btnVAnadir = Nuevo-Boton $pVid 'Añadir vídeos o fotos' 2 350 290 52 $true
$btnVSubir  = Nuevo-Boton $pVid 'Subir' 302 350 96 52 $false
$btnVBajar  = Nuevo-Boton $pVid 'Bajar' 404 350 96 52 $false
$btnVQuitar = Nuevo-Boton $pVid 'Quitar' 506 350 96 52 $false
foreach ($b in @($btnVAnadir, $btnVSubir, $btnVBajar, $btnVQuitar)) { $b.Anchor = 'Bottom,Left' }
$lblRecorte = Nuevo-Label $pVid 'Recortar el elegido (segundos):' 2 416 600 28 $Fuente $Gris
Nuevo-Label $pVid 'Desde' 2 452 70 30 $Fuente $Blanco | Out-Null
$txtDesde = Nueva-Caja $pVid 74 448 110 36 $false
Nuevo-Label $pVid 'Hasta' 204 452 70 30 $Fuente $Blanco | Out-Null
$txtHasta = Nueva-Caja $pVid 276 448 110 36 $false
Nuevo-Label $pVid '(vacío = hasta el final; en fotos, Hasta = segundos que sale)' 2 492 600 28 $Fuente $Gris | Out-Null
foreach ($c in @($lblRecorte, $txtDesde, $txtHasta)) { $c.Anchor = 'Bottom,Left' }

$X = 640
Nuevo-Label $pVid 'Título del principio' $X 4 300 28 $Fuente $Gris | Out-Null
$txtTitulo = Nueva-Caja $pVid $X 34 598 36 $false
Nuevo-Label $pVid 'Subtítulo' $X 76 300 28 $Fuente $Gris | Out-Null
$txtSub = Nueva-Caja $pVid $X 106 598 36 $false
Nuevo-Label $pVid 'Texto del final (puede tener 2 líneas)' $X 148 400 28 $Fuente $Gris | Out-Null
$txtFinal = Nueva-Caja $pVid $X 178 598 62 $true
$txtFinal.ScrollBars = 'None'
foreach ($c in @($txtTitulo, $txtSub, $txtFinal)) { $c.Anchor = 'Top,Left,Right' }
$btnVMusica = Nuevo-Boton $pVid 'Música de fondo' $X 252 210 46 $false
$btnVSinMusica = Nuevo-Boton $pVid 'Sin música' ($X + 218) 252 140 46 $false
$lblMusica = Nuevo-Label $pVid 'Sin música' ($X + 366) 262 240 28 $Fuente $Blanco
$lblMusica.Anchor = 'Top,Left,Right'
Nuevo-Label $pVid 'Volumen música' $X 310 150 28 $Fuente $Gris | Out-Null
$volMusica = New-Object System.Windows.Forms.TrackBar
Pos $volMusica ($X + 150) 304 300 40; $volMusica.Minimum = 5; $volMusica.Maximum = 100; $volMusica.Value = 35
$volMusica.TickFrequency = 10; $volMusica.BackColor = $Negro
$pVid.Controls.Add($volMusica)
$chkSonido = New-Object System.Windows.Forms.CheckBox
$chkSonido.Text = 'Mantener el sonido de los vídeos (la música baja sola cuando se habla)'
Pos $chkSonido $X 350 598 30; $chkSonido.Checked = $true; $chkSonido.ForeColor = $Blanco
$pVid.Controls.Add($chkSonido)
Nuevo-Label $pVid 'Formato' $X 392 120 28 $Fuente $Gris | Out-Null
$cmbFormato = Nuevo-Combo $pVid ($X + 120) 388 420 @('Horizontal Full HD (YouTube, TV)', 'Horizontal 4K', 'Vertical (TikTok, Reels, Shorts)', 'Cuadrado (Instagram)')
Nuevo-Label $pVid 'Transición' $X 432 120 28 $Fuente $Gris | Out-Null
$cmbTrans = Nuevo-Combo $pVid ($X + 120) 428 260 @('Fundido', 'Deslizar', 'Zoom', 'Ninguna')
Nuevo-Label $pVid 'Seg. por foto' ($X + 396) 432 130 28 $Fuente $Gris | Out-Null
$numFoto = New-Object System.Windows.Forms.NumericUpDown
Pos $numFoto ($X + 528) 428 70 34; $numFoto.Minimum = 1; $numFoto.Maximum = 30; $numFoto.Value = 4
$numFoto.BackColor = $Caja; $numFoto.ForeColor = $Blanco
$pVid.Controls.Add($numFoto)
$btnVCrear = Nuevo-Boton $pVid 'CREAR VÍDEO' $X 482 380 66 $true
$btnVCrear.Font = $FuenteGrande
$btnVVer = Nuevo-Boton $pVid 'Ver el vídeo' ($X + 394) 482 204 66 $false
foreach ($b in @($btnVCrear, $btnVVer)) { $b.Anchor = 'Bottom,Left' }

Mover-Dentro $pDesc; Mover-Dentro $pKara; Mover-Dentro $pVid

# ---------- cambiar de sección ----------
$secciones = @{ desc = @($pDesc, $tabDesc); kara = @($pKara, $tabKara); vid = @($pVid, $tabVid) }
function Mostrar($nombre) {
    foreach ($k in $secciones.Keys) {
        $p = $secciones[$k][0]; $t = $secciones[$k][1]
        $vis = ($k -eq $nombre)
        $p.Visible = $vis
        if ($vis) { $t.BackColor = $Oro; $t.ForeColor = $Negro } else { $t.BackColor = $Panel; $t.ForeColor = $Oro }
        $Jobs[$k].barra.Visible = $vis; $Jobs[$k].lbl.Visible = $vis; $Jobs[$k].log.Visible = $vis
    }
    $script:visible = $nombre
}
$tabDesc.Add_Click({ Mostrar 'desc' })
$tabKara.Add_Click({ Mostrar 'kara' })
$tabVid.Add_Click({ Mostrar 'vid' })

$Jobs['desc'].botones = @($btnVideo, $btnMp3, $btnConvertir)
$Jobs['kara'].botones = @($btnKCrear, $btnKRehacer, $btnKOtro)
$Jobs['vid'].botones  = @($btnVCrear)
function Ocupado($si) { foreach ($b in $Jobs[$script:JK].botones) { $b.Enabled = -not $si } }
function Estado($texto, $error) {
    $lblEstado.Text = $texto
    if ($error) { $lblEstado.ForeColor = $Rojo } else { $lblEstado.ForeColor = $Oro }
}
function Aviso($texto) { [System.Windows.Forms.MessageBox]::Show($texto, 'VYA ESTUDIO') | Out-Null }

# ---------- ejecutar procesos sin ventana negra y leer su progreso (uno por sección) ----------
function Lanzar($exe, $argumentos, $alTerminar) {
    # La salida va a un archivo y el reloj la va leyendo: así la ventana nunca se queda colgada.
    $j = $Jobs[$script:JK]
    [System.IO.File]::WriteAllText($j.logFile, '')
    $j.pos = 0; $j.resto = ''; $j.error = $null; $j.archivo = $null
    $script:ultimoArchivo = $null; $script:ultimoError = $null
    $psi = New-Object System.Diagnostics.ProcessStartInfo
    $psi.FileName = $env:ComSpec
    $psi.Arguments = '/d /s /c ""' + $exe + '" ' + $argumentos + ' > "' + $j.logFile + '" 2>&1"'
    $psi.UseShellExecute = $false; $psi.CreateNoWindow = $true
    $psi.WindowStyle = 'Hidden'
    $psi.EnvironmentVariables['PATH'] = $Bin + ';' + $psi.EnvironmentVariables['PATH']
    $psi.EnvironmentVariables['PYTHONIOENCODING'] = 'utf-8'
    $psi.EnvironmentVariables['PYTHONUNBUFFERED'] = '1'
    $psi.EnvironmentVariables['HF_HUB_DISABLE_SYMLINKS_WARNING'] = '1'
    $j.fn = $alTerminar
    $j.proc = [System.Diagnostics.Process]::Start($psi)
}

function Leer-Nuevas($j) {
    $lineas = @()
    if (-not (Test-Path $j.logFile)) { return $lineas }
    try {
        $fs = New-Object System.IO.FileStream($j.logFile, 'Open', 'Read', 'ReadWrite')
        if ($fs.Length -gt $j.pos) {
            $fs.Seek($j.pos, 'Begin') | Out-Null
            $buf = New-Object byte[] ($fs.Length - $j.pos)
            $n = $fs.Read($buf, 0, $buf.Length)
            $j.pos += $n
            $texto = $j.resto + [System.Text.Encoding]::UTF8.GetString($buf, 0, $n)
            $partes = $texto -split "`r?`n|`r"
            $j.resto = $partes[-1]
            if ($partes.Count -gt 1) { $lineas = $partes[0..($partes.Count - 2)] }
        }
        $fs.Close()
    } catch {}
    return $lineas
}

function Poner-Estado($j, $texto, $error) {
    $j.lbl.Text = $texto
    if ($error) { $j.lbl.ForeColor = $Rojo } else { $j.lbl.ForeColor = $Oro }
}

$reloj = New-Object System.Windows.Forms.Timer
$reloj.Interval = 250
$reloj.Add_Tick({
    foreach ($k in @('desc', 'kara', 'vid')) {
        $j = $Jobs[$k]
        if (-not $j.proc) { continue }
        $nuevas = @(Leer-Nuevas $j)
        if ($j.proc.HasExited -and $j.resto) { $nuevas += $j.resto; $j.resto = '' }
        foreach ($linea in $nuevas) {
            $linea = $linea.TrimStart([char]0xFEFF)
            if (-not $linea) { continue }
            if ($linea -match '\[download\]\s+([\d\.]+)%') {
                $pct = [math]::Min(100, [int][double]::Parse($Matches[1], $Inv)); $j.barra.Style = 'Blocks'; $j.barra.Value = $pct
                Poner-Estado $j "Descargando… $pct %"
            } elseif ($linea -match '^PCT (\d+)') {
                $j.barra.Style = 'Blocks'; $j.barra.Value = [math]::Min(100, [int]$Matches[1])
            } elseif ($linea -match '^PASO (.+)$') {
                Poner-Estado $j $Matches[1]; $j.log.AppendText($Matches[1] + [Environment]::NewLine)
            } elseif ($linea -match '^(ARCHIVO|CARPETA) (.+)$') {
                $j.archivo = $Matches[2].Trim()
            } elseif ($linea -match '^ERROR:? (.+)$') {
                $j.error = $Matches[1]; $j.log.AppendText('ERROR: ' + $Matches[1] + [Environment]::NewLine)
            } elseif ($linea -match 'time=(\d+:\d+:\d+)') {
                Poner-Estado $j ('Convirtiendo… ' + $Matches[1])
            } else {
                $j.log.AppendText($linea + [Environment]::NewLine)
            }
        }
        if ($j.proc.HasExited) {
            $codigo = $j.proc.ExitCode; $j.proc = $null
            $fn = $j.fn; $j.fn = $null
            if ($fn) { Usar $k; & $fn $codigo }
        }
    }
})
$reloj.Start()

# ---------- preparar herramientas ----------
$script:preparando = $false
function Preparar($conKaraoke, $despues) {
    $faltaBase = -not ((Test-Path $YtDlp) -and (Test-Path $Ffmpeg) -and (Test-Path $PyExe) -and (Test-Path $Deno))
    $faltaKara = $conKaraoke -and -not (Test-Path (Join-Path $Base 'python\Lib\site-packages\faster_whisper'))
    if (-not $faltaBase -and -not $faltaKara) { & $despues; return }
    if ($script:preparando) { Aviso 'Estoy preparando las herramientas. Espera a que termine y vuelve a pulsar.'; return }
    $script:preparando = $true
    Ocupado $true; $barra.Style = 'Marquee'
    if ($faltaKara) { Estado 'Primera vez con el karaoke: instalando el quitavoces y el oído de la letra… (espera, los botones se activan al terminar)' }
    else { Estado 'Preparando las herramientas… espera, los botones se activan al terminar' }
    $Jobs[$script:JK].despues = $despues
    $ps = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
    $scr = Join-Path $Base 'preparar.ps1'
    $extra = ''; if ($faltaKara) { $extra = ' -Karaoke' }
    Lanzar $ps ("-NoProfile -ExecutionPolicy Bypass -File `"$scr`" -Base `"$Base`"" + $extra) {
        param($c)
        $script:preparando = $false
        $barra.Style = 'Blocks'; Ocupado $false
        $j = $Jobs[$script:JK]
        if ($c -eq 0) { $fn = $j.despues; $j.despues = $null; & $fn }
        else { Estado 'No se pudo preparar (¿hay internet?). Cierra y vuelve a abrir VYA ESTUDIO.' $true }
    }
}
function Actualizar-Motor {
    Estado 'Comprobando actualizaciones…'
    Lanzar $YtDlp '-U' { param($c) Estado 'Listo.'; $barra.Value = 0 }
}

$btnDetalle.Add_Click({
    $copia = Join-Path $env:TEMP 'VYA_ESTUDIO_detalle.txt'
    try { Copy-Item $Jobs[$script:visible].logFile $copia -Force; Start-Process notepad.exe $copia } catch { Aviso 'Todavía no hay detalle.' }
})

# ---------- carpeta ----------
$btnAbrir.Add_Click({ Start-Process explorer.exe $script:Destino })

# ===== acciones DESCARGAR =====
function Descargar($soloAudio) {
    Usar 'desc'
    $url = $txtUrl.Text.Trim()
    if ($url -notmatch '^https?://') { Aviso 'Pega primero un enlace (empieza por https://).'; return }
    Ocupado $true; $barra.Value = 0; $log.Clear()
    $dir = $DirVideos; if ($soloAudio) { $dir = $DirMp3 }
    $plantilla = '"' + (Join-Path $dir '%(title)s.%(ext)s') + '"'
    $comun = "--newline --no-playlist --encoding utf-8 --remote-components ejs:github --ffmpeg-location `"$Bin`" -o $plantilla"
    if ($soloAudio) { Estado 'Descargando música…'; $a = "$comun -x --audio-format mp3 --audio-quality 0 `"$url`"" }
    else { Estado 'Descargando vídeo…'; $a = "$comun -f `"bv*[ext=mp4]+ba[ext=m4a]/b[ext=mp4]/b`" --merge-output-format mp4 `"$url`"" }
    Lanzar $YtDlp $a {
        param($c)
        Ocupado $false
        if ($c -eq 0) { $barra.Value = 100; Estado 'Hecho. Guardado en VYA ESTUDIO ARCHIVOS.' }
        else { $m = 'No se pudo descargar.'; if ($script:ultimoError) { $m += ' ' + $script:ultimoError }; Estado $m $true }
    }
}
$btnVideo.Add_Click({ Descargar $false })
$btnMp3.Add_Click({ Descargar $true })
$btnPegar.Add_Click({ $txtUrl.Text = [System.Windows.Forms.Clipboard]::GetText().Trim() })
$btnConvertir.Add_Click({
    Usar 'desc'
    $o = New-Object System.Windows.Forms.OpenFileDialog
    $o.Title = 'Elige el vídeo que quieres pasar a MP3'; $o.InitialDirectory = $DirVideos
    $o.Filter = 'Vídeos|*.mp4;*.mkv;*.webm;*.mov;*.avi;*.m4v|Todos|*.*'
    if ($o.ShowDialog() -ne 'OK') { return }
    $salida = Join-Path $DirMp3 ([IO.Path]::GetFileNameWithoutExtension($o.FileName) + '.mp3')
    Ocupado $true; $log.Clear(); $barra.Style = 'Marquee'
    Estado 'Convirtiendo a MP3…'
    Lanzar $Ffmpeg ("-y -i `"" + $o.FileName + "`" -vn -c:a libmp3lame -q:a 0 `"" + $salida + "`"") {
        param($c)
        $barra.Style = 'Blocks'; Ocupado $false
        if ($c -eq 0) { $barra.Value = 100; Estado 'Hecho. Guardado en MP3 DESCARGADOS.' }
        else { Estado 'No se pudo convertir. Mira el detalle abajo.' $true }
    }
})

# ===== acciones KARAOKE (con cola) =====
$script:karaCarpeta = $null
$script:cola = New-Object System.Collections.ArrayList
$script:itemActual = $null
function Refrescar-Cola {
    $sel = $lstCola.SelectedIndex
    $lstCola.Items.Clear()
    foreach ($c in $script:cola) { [void]$lstCola.Items.Add(($c.estado + '   ·   ' + $c.nombre)) }
    if ($sel -ge 0 -and $sel -lt $lstCola.Items.Count) { $lstCola.SelectedIndex = $sel }
}
function Agregar-Cola($tipo, $valor, $nombre) {
    [void]$script:cola.Add(@{ tipo = $tipo; valor = $valor; nombre = $nombre; estado = 'En espera'; carpeta = $null })
    Refrescar-Cola
}
function Agregar-Enlace {
    $url = $txtKUrl.Text.Trim()
    if (-not $url) { return }
    if ($url -notmatch '^https?://') { Aviso 'El enlace tiene que empezar por https://'; return }
    Agregar-Cola 'enlace' $url ('Enlace: ' + $url); $txtKUrl.Text = ''
}
$btnKElegir.Add_Click({
    $o = New-Object System.Windows.Forms.OpenFileDialog
    $o.Title = 'Elige canciones o vídeos (puedes elegir varios)'; $o.InitialDirectory = $DirMp3; $o.Multiselect = $true
    $o.Filter = 'Canciones y vídeos|*.mp3;*.wav;*.m4a;*.flac;*.ogg;*.aac;*.wma;*.mp4;*.mkv;*.webm;*.mov;*.avi;*.m4v|Todos|*.*'
    if ($o.ShowDialog() -ne 'OK') { return }
    foreach ($n in $o.FileNames) { Agregar-Cola 'archivo' $n ([IO.Path]::GetFileName($n)) }
})
$btnKPegar.Add_Click({ $txtKUrl.Text = [System.Windows.Forms.Clipboard]::GetText().Trim(); Agregar-Enlace })
$txtKUrl.Add_KeyDown({ param($s2, $e2) if ($e2.KeyCode -eq 'Return') { Agregar-Enlace; $e2.SuppressKeyPress = $true } })
$btnKLimpiar.Add_Click({ $txtLetra.Clear(); $txtLetra.Focus() | Out-Null })
$btnKQuitar.Add_Click({
    $i = $lstCola.SelectedIndex; if ($i -lt 0) { return }
    if ($script:cola[$i].estado -eq 'Haciendo…') { Aviso 'Ese se está haciendo ahora, espera a que termine.'; return }
    $script:cola.RemoveAt($i); Refrescar-Cola
})
$btnKVaciar.Add_Click({
    foreach ($c in @($script:cola)) { if ($c.estado -ne 'Haciendo…') { $script:cola.Remove($c) } }
    Refrescar-Cola
})
$lstCola.Add_DoubleClick({
    $i = $lstCola.SelectedIndex; if ($i -lt 0) { return }
    $c = $script:cola[$i]
    if ($c.carpeta) { $script:karaCarpeta = $c.carpeta; Cargar-Letra; Estado ('Karaoke abierto: ' + $c.nombre) }
})

function Datos-Kara($c) {
    $d = Join-Path $c '_datos'
    if (Test-Path -LiteralPath $d) { return $d } else { return $c }
}
function Cargar-Letra {
    if (-not $script:karaCarpeta) { return }
    $l = Join-Path (Datos-Kara $script:karaCarpeta) 'letra.txt'
    if (Test-Path -LiteralPath $l) { $txtLetra.Text = ([IO.File]::ReadAllText($l, [Text.Encoding]::UTF8)).TrimStart([char]0xFEFF) -replace "`r?`n", "`r`n" }
}
function Siguiente-Karaoke {
    Usar 'kara'
    $item = $null
    foreach ($c in $script:cola) { if ($c.estado -eq 'En espera') { $item = $c; break } }
    if (-not $item) {
        $script:itemActual = $null; Ocupado $false
        $hechos = @($script:cola | Where-Object { $_.estado -eq 'HECHO' }).Count
        $fallos = @($script:cola | Where-Object { $_.estado -eq 'ERROR' }).Count
        $m = "Cola terminada: $hechos karaoke(s) hecho(s)."
        if ($fallos) { $m += " $fallos con error." }
        Estado $m ($fallos -gt 0); $barra.Value = 100
        try { [System.Media.SystemSounds]::Asterisk.Play() } catch {}
        return
    }
    $script:itemActual = $item; $item.estado = 'Haciendo…'; Refrescar-Cola
    Ocupado $true; $barra.Value = 0; $log.Clear()
    if ($item.tipo -eq 'enlace') {
        Estado ('Bajando la canción del enlace…')
        $plantilla = '"' + (Join-Path $DirVideos '%(title)s.%(ext)s') + '"'
        $a = "--newline --no-playlist --encoding utf-8 --remote-components ejs:github --ffmpeg-location `"$Bin`" -o $plantilla -f `"bv*[ext=mp4]+ba[ext=m4a]/b[ext=mp4]/b`" --merge-output-format mp4 --no-simulate --progress --print `"after_move:ARCHIVO %(filepath)s`" `"$($item.valor)`""
        Lanzar $YtDlp $a {
            param($c)
            $it = $script:itemActual
            if ($c -eq 0 -and $script:ultimoArchivo -and (Test-Path -LiteralPath $script:ultimoArchivo)) {
                $it.valor = $script:ultimoArchivo; $it.tipo = 'archivo'; $it.nombre = [IO.Path]::GetFileName($script:ultimoArchivo)
                Refrescar-Cola
                Kara-Lanzar $it.valor
            } else { $it.estado = 'ERROR'; Refrescar-Cola; Siguiente-Karaoke }
        }
    } else { Kara-Lanzar $item.valor }
}
function Kara-Lanzar($archivo) {
    $calidad = 'rapida'; if ($rbPrecisa.Checked) { $calidad = 'precisa' }
    $idioma = @('es', 'en', 'auto')[$cmbIdioma.SelectedIndex]
    $pend = @($script:cola | Where-Object { $_.estado -eq 'En espera' }).Count
    Estado ('Creando karaoke: ' + [IO.Path]::GetFileName($archivo) + $(if ($pend) { "   (quedan $pend en la cola)" } else { '' }))
    $a = "-u `"" + (Join-Path $Motor 'karaoke.py') + "`" crear `"$archivo`" `"$DirKaraokes`" `"$Bin`" `"$Modelos`" $calidad $idioma"
    Lanzar $PyExe $a {
        param($c)
        $it = $script:itemActual
        if ($c -eq 0 -and $script:ultimoArchivo) {
            $it.estado = 'HECHO'; $it.carpeta = $script:ultimoArchivo
            $script:karaCarpeta = $script:ultimoArchivo; Cargar-Letra
        } else {
            $it.estado = 'ERROR'
            if ($script:ultimoError) { $log.AppendText('ERROR: ' + $script:ultimoError + [Environment]::NewLine) }
        }
        Refrescar-Cola
        Siguiente-Karaoke
    }
}
$btnKCrear.Add_Click({
    Usar 'kara'
    Agregar-Enlace
    $pend = @($script:cola | Where-Object { $_.estado -eq 'En espera' }).Count
    if (-not $pend) { Aviso 'Añade primero alguna canción a la cola (del PC o con un enlace).'; return }
    Preparar $true { Siguiente-Karaoke }
})
$btnKRehacer.Add_Click({
    Usar 'kara'
    if (-not $script:karaCarpeta) { Aviso 'Primero crea un karaoke o pulsa Abrir otro karaoke.'; return }
    [IO.File]::WriteAllText((Join-Path (Datos-Kara $script:karaCarpeta) 'letra.txt'), $txtLetra.Text, (New-Object System.Text.UTF8Encoding($true)))
    Ocupado $true; $barra.Value = 0; $log.Clear(); $script:ultimoArchivo = $null
    $a = "-u `"" + (Join-Path $Motor 'karaoke.py') + "`" rehacer `"$($script:karaCarpeta)`" `"$Bin`""
    Lanzar $PyExe $a {
        param($c)
        Ocupado $false
        if ($c -eq 0) { $barra.Value = 100; Estado '¡Vídeo rehecho con tu letra!' }
        else { $m = 'No se pudo rehacer el vídeo.'; if ($script:ultimoError) { $m += ' ' + $script:ultimoError }; Estado $m $true }
    }
})
$btnKVer.Add_Click({
    if (-not $script:karaCarpeta) { Aviso 'Todavía no hay ningún karaoke hecho.'; return }
    $v = Get-ChildItem -LiteralPath $script:karaCarpeta -Filter '*(karaoke).mp4' | Select-Object -First 1
    if ($v) { Start-Process -FilePath $v.FullName } else { Aviso 'No encuentro el vídeo de este karaoke.' }
})
$btnKCarpeta.Add_Click({ if ($script:karaCarpeta) { Start-Process explorer.exe $script:karaCarpeta } else { Start-Process explorer.exe $DirKaraokes } })
$btnKOtro.Add_Click({
    $d = New-Object System.Windows.Forms.FolderBrowserDialog
    $d.Description = 'Elige la carpeta del karaoke (la que termina en - KARAOKE)'
    $d.SelectedPath = $DirKaraokes
    if ($d.ShowDialog() -ne 'OK') { return }
    if (-not (Test-Path -LiteralPath (Join-Path (Datos-Kara $d.SelectedPath) 'tiempos.json'))) { Aviso 'Esa carpeta no es de un karaoke de VYA ESTUDIO.'; return }
    $script:karaCarpeta = $d.SelectedPath; Cargar-Letra
    Estado ('Karaoke abierto: ' + (Split-Path $d.SelectedPath -Leaf))
})

# ===== acciones VÍDEO PRO =====
$script:clips = New-Object System.Collections.ArrayList
$script:musica = ''
$script:ultimoVideo = $null
$script:cargandoRecorte = $false
function Texto-Clip($c) {
    $t = [IO.Path]::GetFileName($c.ruta)
    if ($c.desde -or $c.hasta) { $t += "   [$($c.desde) - $(if ($c.hasta) { $c.hasta } else { 'final' }) s]" }
    return $t
}
function Refrescar-Lista($sel) {
    $lista.Items.Clear()
    foreach ($c in $script:clips) { [void]$lista.Items.Add((Texto-Clip $c)) }
    if ($sel -ge 0 -and $sel -lt $lista.Items.Count) { $lista.SelectedIndex = $sel }
}
function Numero($t) {
    $t = ($t -replace ',', '.').Trim(); $v = 0.0
    if ([double]::TryParse($t, [System.Globalization.NumberStyles]::Float, $Inv, [ref]$v) -and $v -ge 0) { return $v }
    return 0.0
}
$btnVAnadir.Add_Click({
    $o = New-Object System.Windows.Forms.OpenFileDialog
    $o.Title = 'Elige vídeos y fotos (puedes elegir varios)'; $o.Multiselect = $true; $o.InitialDirectory = $DirVideos
    $o.Filter = 'Vídeos y fotos|*.mp4;*.mov;*.mkv;*.webm;*.avi;*.m4v;*.jpg;*.jpeg;*.png;*.bmp;*.webp|Todos|*.*'
    if ($o.ShowDialog() -ne 'OK') { return }
    foreach ($n in $o.FileNames) { [void]$script:clips.Add(@{ ruta = $n; desde = 0; hasta = 0 }) }
    Refrescar-Lista ($script:clips.Count - 1)
})
$btnVQuitar.Add_Click({
    $i = $lista.SelectedIndex; if ($i -lt 0) { return }
    $script:clips.RemoveAt($i); Refrescar-Lista ([math]::Min($i, $script:clips.Count - 1))
})
$btnVSubir.Add_Click({
    $i = $lista.SelectedIndex; if ($i -le 0) { return }
    $c = $script:clips[$i]; $script:clips.RemoveAt($i); $script:clips.Insert($i - 1, $c); Refrescar-Lista ($i - 1)
})
$btnVBajar.Add_Click({
    $i = $lista.SelectedIndex; if ($i -lt 0 -or $i -ge $script:clips.Count - 1) { return }
    $c = $script:clips[$i]; $script:clips.RemoveAt($i); $script:clips.Insert($i + 1, $c); Refrescar-Lista ($i + 1)
})
$lista.Add_SelectedIndexChanged({
    $i = $lista.SelectedIndex; if ($i -lt 0) { return }
    $script:cargandoRecorte = $true
    $c = $script:clips[$i]
    $txtDesde.Text = $(if ($c.desde) { [string]$c.desde } else { '' })
    $txtHasta.Text = $(if ($c.hasta) { [string]$c.hasta } else { '' })
    $lblRecorte.Text = 'Recortar: ' + [IO.Path]::GetFileName($c.ruta)
    $script:cargandoRecorte = $false
})
$guardarRecorte = {
    if ($script:cargandoRecorte) { return }
    $i = $lista.SelectedIndex; if ($i -lt 0) { return }
    $script:clips[$i].desde = Numero $txtDesde.Text
    $script:clips[$i].hasta = Numero $txtHasta.Text
    $script:cargandoRecorte = $true
    $lista.Items[$i] = Texto-Clip $script:clips[$i]
    $script:cargandoRecorte = $false
}
$txtDesde.Add_Leave($guardarRecorte); $txtHasta.Add_Leave($guardarRecorte)
$btnVMusica.Add_Click({
    $o = New-Object System.Windows.Forms.OpenFileDialog
    $o.Title = 'Elige la música de fondo'; $o.InitialDirectory = $DirMp3
    $o.Filter = 'Música|*.mp3;*.wav;*.m4a;*.flac;*.ogg;*.aac|Todos|*.*'
    if ($o.ShowDialog() -ne 'OK') { return }
    $script:musica = $o.FileName; $lblMusica.Text = [IO.Path]::GetFileName($o.FileName)
})
$btnVSinMusica.Add_Click({ $script:musica = ''; $lblMusica.Text = 'Sin música' })

$btnVCrear.Add_Click({
    Usar 'vid'
    & $guardarRecorte
    if ($script:clips.Count -eq 0) { Aviso 'Añade primero algún vídeo o foto.'; return }
    $s = New-Object System.Windows.Forms.SaveFileDialog
    $s.Title = 'Guardar el vídeo como'; $s.Filter = 'Vídeo MP4|*.mp4'
    $s.InitialDirectory = $DirGenerados
    $s.FileName = 'VYA video ' + (Get-Date -Format 'yyyy-MM-dd HHmm') + '.mp4'
    if ($s.ShowDialog() -ne 'OK') { return }
    $formatos = @('horizontal', '4k', 'vertical', 'cuadrado')
    $trans = @('fundido', 'deslizar', 'zoom', 'ninguna')
    $lst = @()
    foreach ($c in $script:clips) { $lst += [ordered]@{ ruta = $c.ruta; desde = [double]$c.desde; hasta = [double]$c.hasta } }
    $trabajo = [ordered]@{
        salida = $s.FileName; formato = $formatos[$cmbFormato.SelectedIndex]; transicion = $trans[$cmbTrans.SelectedIndex]
        titulo = $txtTitulo.Text.Trim(); subtitulo = $txtSub.Text.Trim(); final = ($txtFinal.Text.Trim() -replace "`r", '')
        musica = $script:musica; volumen_musica = [double]($volMusica.Value / 100.0); sonido_original = [bool]$chkSonido.Checked
        segundos_foto = [int]$numFoto.Value; clips = $lst
    }
    $json = Join-Path $env:TEMP 'vya_trabajo_video.json'
    [IO.File]::WriteAllText($json, (ConvertTo-Json $trabajo -Depth 5), (New-Object System.Text.UTF8Encoding($false)))
    $log.Clear()
    $script:jsonTrabajo = $json
    Preparar $false {
        Ocupado $true; $barra.Value = 0; $script:ultimoArchivo = $null
        Estado 'Montando el vídeo…'
        $a = "-u `"" + (Join-Path $Motor 'montaje.py') + "`" `"$($script:jsonTrabajo)`" `"$Bin`""
        Lanzar $PyExe $a {
            param($c)
            Ocupado $false
            if ($c -eq 0 -and $script:ultimoArchivo) { $script:ultimoVideo = $script:ultimoArchivo; $barra.Value = 100; Estado '¡Vídeo terminado! Pulsa Ver el vídeo.' }
            else { $m = 'No se pudo crear el vídeo.'; if ($script:ultimoError) { $m += ' ' + $script:ultimoError }; Estado $m $true }
        }
    }
})
$btnVVer.Add_Click({
    if ($script:ultimoVideo -and (Test-Path -LiteralPath $script:ultimoVideo)) { Start-Process -FilePath $script:ultimoVideo }
    else { Aviso 'Todavía no has creado ningún vídeo.' }
})

# ---------- arranque ----------
Mostrar 'desc'
$f.Add_Shown({ Usar 'desc'; Preparar $false { Actualizar-Motor } })
$f.Add_FormClosing({ foreach ($j in $Jobs.Values) { if ($j.proc -and -not $j.proc.HasExited) { try { $j.proc.Kill() } catch {} } } })
[void]$f.ShowDialog()
