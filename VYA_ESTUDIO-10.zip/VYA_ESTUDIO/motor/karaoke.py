"""VYA ESTUDIO - motor de karaoke.

  python karaoke.py crear  <archivo> <carpeta_salida> <bin_ffmpeg> <modelos> [rapida|precisa]
  python karaoke.py rehacer <carpeta_del_karaoke> <bin_ffmpeg>

crear:   quita la voz, saca la letra palabra a palabra y hace el vídeo MP4 de karaoke.
rehacer: vuelve a hacer el vídeo después de corregir letra.txt (una línea por frase).
Imprime "PASO texto" y "PCT n" para que la ventana muestre el progreso.
"""
import json
import os
import re
import subprocess
import sys

import numpy as np

AQUI = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, AQUI)
import separar  # noqa: E402
import letras  # noqa: E402

MODELO_UVR = ('UVR-MDX-NET-Inst_HQ_3.onnx', 3072, 6144, 1.022)  # quita todas las voces (también los coros)
URL_UVR = 'https://github.com/TRvlvr/model_repo/releases/download/all_public_uvr_models/'
ORO, BLANCO = '&H005AAFD4', '&H00FFFFFF'
OCULTO = 0x08000000 if os.name == 'nt' else 0


def datos_dir(carpeta, crear=False):
    """Archivos de trabajo en la subcarpeta oculta _datos (el usuario solo ve el vídeo y el MP3)."""
    d = os.path.join(carpeta, '_datos')
    if crear:
        os.makedirs(d, exist_ok=True)
        if os.name == 'nt':
            try:
                import ctypes
                ctypes.windll.kernel32.SetFileAttributesW(d, 0x02)
            except Exception:
                pass
        return d
    if not os.path.isdir(d) and os.path.exists(os.path.join(carpeta, 'tiempos.json')):
        return carpeta  # karaokes hechos con la versión anterior
    return d


def paso(t):
    print('PASO ' + t, flush=True)


def pct(n):
    print(f'PCT {int(n)}', flush=True)


def ff(binff, nombre):
    exe = os.path.join(binff, nombre + ('.exe' if os.name == 'nt' else ''))
    return exe if os.path.exists(exe) else nombre


def ejecutar(cmd, cwd=None):
    r = subprocess.run(cmd, cwd=cwd, capture_output=True, creationflags=OCULTO)
    if r.returncode != 0:
        raise RuntimeError(r.stderr.decode('utf-8', 'replace')[-1500:])
    return r.stdout


def tiene_video(binff, archivo):
    try:
        out = ejecutar([ff(binff, 'ffprobe'), '-v', 'error', '-select_streams', 'v:0',
                        '-show_entries', 'stream=codec_name,width,height', '-of', 'json', archivo])
        s = json.loads(out).get('streams', [])
        return bool(s) and s[0].get('codec_name') not in ('mjpeg', 'png', 'bmp')  # carátulas de MP3 no cuentan
    except Exception:
        return False


def bajar(url, destino):
    import urllib.request
    tmp = destino + '.tmp'
    with urllib.request.urlopen(url, timeout=60) as r, open(tmp, 'wb') as f:
        total = int(r.headers.get('Content-Length') or 0)
        hecho = 0
        while True:
            b = r.read(1 << 16)
            if not b:
                break
            f.write(b)
            hecho += len(b)
            if total:
                pct(100 * hecho / total)
    os.replace(tmp, destino)


# ---------------------------------------------------------------- letra

def agrupar(palabras, max_pal=7, hueco=0.9, max_seg=5.5):
    """Junta palabras en frases cortas para la pantalla."""
    lineas, act = [], []
    for w in palabras:
        if act:
            corta = (w['ini'] - act[-1]['fin'] > hueco or len(act) >= max_pal
                     or w['fin'] - act[0]['ini'] > max_seg or re.search(r'[.!?;]$', act[-1]['t']))
            if corta:
                lineas.append(act)
                act = []
        act.append(w)
    if act:
        lineas.append(act)
    return [{'ini': l[0]['ini'], 'fin': l[-1]['fin'], 'palabras': l} for l in lineas]


def transcribir(voz_wav, binff, modelos, calidad, idioma='es'):
    from faster_whisper import WhisperModel
    nombre = 'medium' if calidad == 'precisa' else 'small'
    paso('Preparando el oído (la primera vez se descarga, tarda un poco)…')
    modelo = WhisperModel(nombre, device='cpu', compute_type='int8',
                          download_root=os.path.join(modelos, 'whisper'))
    raw = ejecutar([ff(binff, 'ffmpeg'), '-v', 'error', '-i', voz_wav, '-ac', '1', '-ar', '16000', '-f', 's16le', '-'])
    audio = np.frombuffer(raw, np.int16).astype(np.float32) / 32768.0
    dur = len(audio) / 16000 or 1
    paso('Escuchando la letra…')
    lengua = None if idioma in ('auto', '') else idioma
    segs, info = modelo.transcribe(audio, language=lengua, word_timestamps=True, vad_filter=True, beam_size=5,
                                   condition_on_previous_text=False)
    palabras = []
    for s in segs:
        for w in (s.words or []):
            t = w.word.strip()
            if t:
                palabras.append({'t': t, 'ini': round(float(w.start), 2), 'fin': round(float(w.end), 2)})
        pct(min(99, 100 * s.end / dur))
    return palabras, info.language


# ---------------------------------------------------------------- subtítulos

def ts(s):
    s = max(0.0, s)
    h = int(s // 3600); m = int(s % 3600 // 60); sec = s % 60
    return f'{h}:{m:02d}:{sec:05.2f}'


def esc(t):
    return t.replace('\\', '').replace('{', '(').replace('}', ')')


def _texto_k(l, desde):
    """Frase con marcas de karaoke: cada palabra se rellena de dorado mientras se canta."""
    partes = []
    espera = int(round((l['ini'] - desde) * 100))
    if espera > 0:
        partes.append(f'{{\\k{espera}}}')
    anterior = l['ini']
    for w in l['palabras']:
        hueco = int(round((w['ini'] - anterior) * 100))
        if hueco > 0:
            partes.append(f'{{\\k{hueco}}}')
        d = max(1, int(round((w['fin'] - w['ini']) * 100)))
        partes.append(f'{{\\kf{d}}}{esc(w["t"])} ')
        anterior = w['fin']
    return ''.join(partes).rstrip()


def _tam(texto):
    n = len(texto)
    return 92 if n <= 34 else (78 if n <= 44 else 64)


def hacer_ass(lineas, titulo, ruta):
    """Dos filas fijas: abajo la frase que se canta (se ilumina en dorado), arriba la siguiente.
    Cada fila solo tiene una frase a la vez, así nunca se montan letras encima de letras."""
    cab = f"""[Script Info]
ScriptType: v4.00+
PlayResX: 1920
PlayResY: 1080
WrapStyle: 2

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Letra,Arial,92,{ORO},{BLANCO},&H00000000,&H96000000,-1,0,0,0,100,100,1,0,1,6,3,2,80,80,300,1
Style: Siguiente,Arial,70,&H00D8D8D8,&H00D8D8D8,&H00000000,&H96000000,-1,0,0,0,100,100,1,0,1,5,2,2,80,80,180,1
Style: Titulo,Arial,84,{ORO},{ORO},&H00000000,&H00000000,-1,0,0,0,100,100,2,0,1,5,0,5,60,60,0,1
Style: Marca,Arial,34,{ORO},{ORO},&H00000000,&H00000000,-1,0,0,0,100,100,6,0,1,2,0,9,50,50,40,1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
"""
    ev = []
    n = len(lineas)
    fin_total = lineas[-1]['fin'] + 3 if lineas else 10
    ev.append(f'Dialogue: 0,{ts(0)},{ts(fin_total)},Marca,,0,0,0,,VYA KARAOKE')
    if not lineas:
        ev.append(f'Dialogue: 0,{ts(0.3)},{ts(8)},Titulo,,0,0,0,,{esc(titulo)}')
    else:
        primero = lineas[0]['ini']
        if primero > 4:
            ev.append(f'Dialogue: 0,{ts(0.3)},{ts(primero - 3.2)},Titulo,,0,0,0,,{{\\fad(400,400)}}{esc(titulo)}')
        # cuándo empieza a verse cada frase (siempre después de que termine la anterior)
        aparece = []
        for i, l in enumerate(lineas):
            a = max(0.0, l['ini'] - 3.0)
            if i > 0:
                a = max(a, lineas[i - 1]['fin'] + 0.05)
            aparece.append(min(a, l['ini']))
        for i, l in enumerate(lineas):
            a = aparece[i]
            b = min(aparece[i + 1], l['fin'] + 2.0) if i + 1 < n else l['fin'] + 2.0
            b = max(b, l['fin'] + 0.05) if i + 1 == n else b
            texto = ' '.join(w['t'] for w in l['palabras'])
            ev.append(f'Dialogue: 1,{ts(a)},{ts(b)},Letra,,0,0,0,,{{\\fs{_tam(texto)}}}' + _texto_k(l, a))
            if i + 1 < n and lineas[i + 1]['ini'] - b < 5:
                sig = ' '.join(w['t'] for w in lineas[i + 1]['palabras'])
                ev.append(f'Dialogue: 1,{ts(a)},{ts(b)},Siguiente,,0,0,0,,{{\\fs{int(_tam(sig) * 0.76)}}}{esc(sig)}')
            # cuenta atrás antes de volver a cantar tras un hueco largo
            if i + 1 < n and lineas[i + 1]['ini'] - l['fin'] > 6:
                t0 = lineas[i + 1]['ini'] - 3
                ev.append(f'Dialogue: 0,{ts(t0)},{ts(t0 + 3)},Titulo,,0,0,0,,{{\\fad(150,150)}}● ● ●')
    with open(ruta, 'w', encoding='utf-8-sig') as f:
        f.write(cab + '\n'.join(ev) + '\n')


def guardar_letra(carpeta, lineas):
    d = datos_dir(carpeta, True)
    with open(os.path.join(d, 'tiempos.json'), 'w', encoding='utf-8') as f:
        json.dump(lineas, f, ensure_ascii=False, indent=1)
    with open(os.path.join(d, 'letra.txt'), 'w', encoding='utf-8-sig') as f:
        f.write('\n'.join(' '.join(w['t'] for w in l['palabras']) for l in lineas) + '\n')


def aplicar_correcciones(carpeta):
    """Mezcla letra.txt (corregida a mano) con los tiempos originales de cada frase."""
    d = datos_dir(carpeta)
    with open(os.path.join(d, 'tiempos.json'), encoding='utf-8') as f:
        lineas = json.load(f)
    with open(os.path.join(d, 'letra.txt'), encoding='utf-8-sig') as f:
        textos = [t.strip() for t in f.read().splitlines()]
    while textos and not textos[-1]:
        textos.pop()
    nuevas = []
    for i, l in enumerate(lineas):
        texto = textos[i] if i < len(textos) else ''
        if not texto:
            continue
        pal = texto.split()
        orig = [w['t'] for w in l['palabras']]
        if pal == orig:
            nuevas.append(l)
            continue
        if len(pal) == len(orig):
            ws = [dict(w, t=p) for w, p in zip(l['palabras'], pal)]
        else:  # reparte el tiempo de la frase según el largo de cada palabra
            tot = sum(len(p) + 1 for p in pal)
            dur = l['fin'] - l['ini']
            t, ws = l['ini'], []
            for p in pal:
                d = dur * (len(p) + 1) / tot
                ws.append({'t': p, 'ini': round(t, 2), 'fin': round(t + d, 2)})
                t += d
        nuevas.append({'ini': l['ini'], 'fin': l['fin'], 'palabras': ws})
    return letras.sanear(nuevas)


# ---------------------------------------------------------------- vídeo

def hacer_video(carpeta, binff):
    d = datos_dir(carpeta)
    with open(os.path.join(d, 'datos.json'), encoding='utf-8') as f:
        datos = json.load(f)
    paso('Haciendo el vídeo de karaoke…')
    ffm = ff(binff, 'ffmpeg')
    salida = os.path.abspath(os.path.join(carpeta, datos['nombre'] + ' (karaoke).mp4'))
    dur = datos['duracion']
    if datos.get('video'):
        fondo = ['-i', datos['original']]
        filtro = ('[0:v]scale=1920:1080:force_original_aspect_ratio=decrease,pad=1920:1080:(ow-iw)/2:(oh-ih)/2,'
                  'setsar=1,eq=brightness=-0.18:saturation=0.85,'
                  'drawbox=x=0:y=ih-470:w=iw:h=470:color=black@0.45:t=fill,subtitles=letra.ass[v]')
    else:
        fondo = ['-f', 'lavfi', '-i', f'color=c=0x0B0B0B:s=1920x1080:r=30:d={dur + 1}']
        filtro = ('[0:v]drawbox=x=0:y=0:w=iw:h=10:color=0xD4AF5A:t=fill,drawbox=x=0:y=ih-10:w=iw:h=10:color=0xD4AF5A:t=fill,'
                  'vignette=PI/5,subtitles=letra.ass[v]')
    cmd = [ffm, '-y', '-v', 'error', '-stats'] + fondo + ['-i', 'musica.wav', '-filter_complex', filtro,
                                                         '-map', '[v]', '-map', '1:a', '-c:v', 'libx264', '-preset', 'veryfast',
                                                         '-crf', '20', '-pix_fmt', 'yuv420p', '-c:a', 'aac', '-b:a', '256k',
                                                         '-shortest', '-movflags', '+faststart', salida]
    p = subprocess.Popen(cmd, cwd=d, stderr=subprocess.PIPE, creationflags=OCULTO)
    buf = b''
    while True:
        c = p.stderr.read(1)
        if not c:
            break
        if c in b'\r\n':
            m = re.search(rb'time=(\d+):(\d+):([\d.]+)', buf)
            if m and dur:
                s = int(m.group(1)) * 3600 + int(m.group(2)) * 60 + float(m.group(3))
                pct(min(100, 100 * s / dur))
            buf = b''
        else:
            buf += c
    if p.wait() != 0:
        raise RuntimeError('No se pudo hacer el vídeo')
    return salida


# ---------------------------------------------------------------- órdenes

def crear(archivo, destino, binff, modelos, calidad='rapida', idioma='es'):
    nombre = os.path.splitext(os.path.basename(archivo))[0]
    nombre = re.sub(r'[<>:"/\\|?*]', '', nombre).strip() or 'cancion'
    carpeta = os.path.join(destino, nombre + ' - KARAOKE')
    os.makedirs(carpeta, exist_ok=True)
    os.makedirs(modelos, exist_ok=True)
    d = datos_dir(carpeta, True)

    uvr = os.path.join(modelos, MODELO_UVR[0])
    if not os.path.exists(uvr):
        paso('Descargando el quitavoces (solo la primera vez)…')
        bajar(URL_UVR + MODELO_UVR[0], uvr)

    paso('Leyendo la canción…')
    mezcla = os.path.join(d, 'original.wav')
    ejecutar([ff(binff, 'ffmpeg'), '-y', '-v', 'error', '-i', archivo, '-vn', '-ac', '2', '-ar', '44100',
              '-c:a', 'pcm_s16le', mezcla])

    paso('Quitando la voz…')
    x = separar.leer_wav(mezcla)
    dur = x.shape[1] / separar.SR

    def aviso(s):
        print(s, flush=True)
    musica, voz = separar.separar(x, uvr, MODELO_UVR[1], MODELO_UVR[2], MODELO_UVR[3], aviso)
    separar.escribir_wav(os.path.join(d, 'musica.wav'), musica)
    separar.escribir_wav(os.path.join(d, 'voz.wav'), voz)
    del x, musica, voz
    ejecutar([ff(binff, 'ffmpeg'), '-y', '-v', 'error', '-i', os.path.join(d, 'musica.wav'),
              '-c:a', 'libmp3lame', '-q:a', '0', os.path.join(carpeta, nombre + ' (sin voz).mp3')])

    palabras, idioma = transcribir(os.path.join(d, 'voz.wav'), binff, modelos, calidad, idioma)
    try:
        os.remove(os.path.join(d, 'voz.wav'))
    except OSError:
        pass
    paso('Buscando la letra oficial de la canción…')
    lrc = letras.buscar_lrc(nombre, dur)
    if lrc:
        lineas, off = letras.lineas_desde_lrc(lrc, palabras, dur)
        fuente = 'oficial'
        paso('Letra oficial encontrada y encajada con la canción.')
    else:
        lineas = letras.agrupar(palabras)
        fuente = 'de oído'
        paso('No hay letra oficial de esta canción: se usa la que se oye (revísala).')
    guardar_letra(carpeta, lineas)
    datos = {'nombre': nombre, 'original': os.path.abspath(archivo), 'video': tiene_video(binff, archivo),
             'duracion': dur, 'idioma': idioma, 'letra': fuente}
    with open(os.path.join(d, 'datos.json'), 'w', encoding='utf-8') as f:
        json.dump(datos, f, ensure_ascii=False, indent=1)
    hacer_ass(lineas, nombre, os.path.join(d, 'letra.ass'))
    mp4 = hacer_video(carpeta, binff)
    try:
        os.remove(mezcla)
    except OSError:
        pass
    print('CARPETA ' + carpeta, flush=True)
    paso('¡Karaoke terminado!')
    return mp4


def rehacer(carpeta, binff):
    paso('Aplicando tus correcciones de la letra…')
    lineas = aplicar_correcciones(carpeta)
    d = datos_dir(carpeta)
    with open(os.path.join(d, 'datos.json'), encoding='utf-8') as f:
        datos = json.load(f)
    hacer_ass(lineas, datos['nombre'], os.path.join(d, 'letra.ass'))
    hacer_video(carpeta, binff)
    print('CARPETA ' + carpeta, flush=True)
    paso('¡Vídeo rehecho con la letra corregida!')


if __name__ == '__main__':
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except Exception:
        pass
    try:
        if sys.argv[1] == 'crear':
            crear(sys.argv[2], sys.argv[3], sys.argv[4], sys.argv[5], sys.argv[6] if len(sys.argv) > 6 else 'rapida',
                  sys.argv[7] if len(sys.argv) > 7 else 'es')
        elif sys.argv[1] == 'rehacer':
            rehacer(sys.argv[2], sys.argv[3])
    except Exception as e:  # noqa: BLE001
        print('ERROR ' + str(e).replace('\n', ' ')[:600], flush=True)
        sys.exit(1)
