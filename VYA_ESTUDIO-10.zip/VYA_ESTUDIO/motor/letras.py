"""VYA ESTUDIO - letra del karaoke.

1. Busca la letra OFICIAL ya sincronizada (LRCLIB, gratis y sin clave).
2. La encaja en la versión exacta de la canción comparándola con lo que se oye (Whisper).
3. Si no la encuentra, usa lo que se oye, pero ordenado y sin frases montadas.
"""
import json
import re
import statistics
import time
import unicodedata
import urllib.parse
import urllib.request
from difflib import SequenceMatcher

AGENTE = 'VYA-ESTUDIO/1.0 (+https://github.com/vyaurbana/vya-estudio)'


# ---------------------------------------------------------------- utilidades

def normal(t):
    t = unicodedata.normalize('NFD', t.lower())
    t = ''.join(c for c in t if unicodedata.category(c) != 'Mn')
    return re.sub(r'[^a-z0-9ñ ]+', ' ', t).split()


def limpiar_nombre(nombre):
    """'Medina Azahara - Todo tiene su fin (Videoclip Oficial)#rock' -> ('Medina Azahara', 'Todo tiene su fin')."""
    n = re.sub(r'[\(\[\{].*?[\)\]\}]', ' ', nombre)
    n = re.sub(r'#\S+', ' ', n)
    n = re.sub(r'(?i)\b(official|oficial|video ?clip|videoclip|video|vídeo|lyrics?|letra|audio|hd|4k|remaster(ed)?|en directo|live)\b', ' ', n)
    n = ''.join(c for c in n if c.isalnum() or c in " -'&.,")
    n = re.sub(r'\s+', ' ', n).strip(' -')
    partes = [p.strip() for p in re.split(r'\s[-–—]\s|\s-|-\s', n) if p.strip()]
    if len(partes) >= 2:
        return partes[0], ' '.join(partes[1:])
    return '', n


def _pedir(url, intentos=3):
    for i in range(intentos):
        try:
            req = urllib.request.Request(url, headers={'User-Agent': AGENTE})
            with urllib.request.urlopen(req, timeout=10) as r:
                return json.loads(r.read().decode('utf-8'))
        except Exception:  # noqa: BLE001  (servidor ocupado, sin internet…)
            time.sleep(3)
    return None


def parse_lrc(texto):
    lineas = []
    for fila in texto.splitlines():
        marcas = re.findall(r'\[(\d+):(\d+(?:\.\d+)?)\]', fila)
        letra = re.sub(r'\[[^\]]*\]', '', fila).strip()
        for m, s in marcas:
            if letra:
                lineas.append((int(m) * 60 + float(s), letra))
    lineas.sort()
    return lineas


def buscar_lrc(nombre, duracion):
    """Devuelve [(segundo, frase), ...] con la letra oficial sincronizada, o None."""
    artista, titulo = limpiar_nombre(nombre)
    consultas = []
    if artista and titulo:
        consultas.append('https://lrclib.net/api/search?' + urllib.parse.urlencode({'artist_name': artista, 'track_name': titulo}))
        consultas.append('https://lrclib.net/api/search?' + urllib.parse.urlencode({'artist_name': titulo, 'track_name': artista}))
    consultas.append('https://lrclib.net/api/search?' + urllib.parse.urlencode({'q': (artista + ' ' + titulo).strip()}))
    mejor = None
    for url in consultas:
        res = _pedir(url)
        if res is None:
            return None  # el servicio no responde: no hacemos esperar más
        if not isinstance(res, list):
            continue
        for r in res:
            if not r.get('syncedLyrics') or r.get('instrumental'):
                continue
            dif = abs(float(r.get('duration') or 0) - duracion)
            if dif > 40:
                continue
            if mejor is None or dif < mejor[0]:
                mejor = (dif, r)
        if mejor:
            break
    if not mejor:
        return None
    lineas = parse_lrc(mejor[1]['syncedLyrics'])
    return lineas or None


# ---------------------------------------------------------------- encajar la letra oficial con lo que se oye

def _desfase(lrc, palabras):
    """Cuánto hay que mover la letra oficial para que cuadre con esta versión (vídeo con intro, etc.)."""
    if not palabras:
        return 0.0
    pw = [(normal(w['t']), w['ini']) for w in palabras]
    pw = [(t[0], ini) for t, ini in pw if t]
    textos = [t for t, _ in pw]
    difs = []
    for seg, frase in lrc:
        objetivo = normal(frase)
        n = len(objetivo)
        if n < 3:
            continue
        mejor = (0.0, None)
        for i in range(0, max(1, len(textos) - n + 1)):
            r = SequenceMatcher(None, objetivo, textos[i:i + n]).ratio()
            if r > mejor[0]:
                mejor = (r, pw[i][1])
        if mejor[0] >= 0.6:
            difs.append(mejor[1] - seg)
    if len(difs) < 2:
        return 0.0
    med = statistics.median(difs)
    cerca = [d for d in difs if abs(d - med) < 2.5]
    return statistics.median(cerca) if cerca else med


def repartir(frase, ini, fin):
    """Reparte el tiempo de la frase entre sus palabras según su largo."""
    pal = frase.split()
    if not pal:
        return []
    fin = max(fin, ini + 0.25 * len(pal))
    tot = sum(len(p) + 1 for p in pal)
    t, ws = ini, []
    for p in pal:
        d = (fin - ini) * (len(p) + 1) / tot
        ws.append({'t': p, 'ini': round(t, 2), 'fin': round(t + d, 2)})
        t += d
    return ws


def lineas_desde_lrc(lrc, palabras, duracion):
    off = _desfase(lrc, palabras)
    lineas = []
    for i, (seg, frase) in enumerate(lrc):
        ini = seg + off
        sig = (lrc[i + 1][0] + off) if i + 1 < len(lrc) else min(duracion, ini + 8)
        # fin real de la frase: última palabra que se oye antes de la siguiente frase
        oidas = [w['fin'] for w in palabras if ini - 0.3 <= w['ini'] < sig - 0.15]
        if oidas:
            fin = min(sig - 0.1, max(oidas))
        else:
            fin = min(sig - 0.1, ini + 0.42 * len(frase.split()) + 0.6)
        if fin <= ini + 0.3:
            fin = min(sig - 0.05, ini + 0.8)
        if ini < 0 or ini >= duracion:
            continue
        lineas.append({'ini': round(ini, 2), 'fin': round(fin, 2), 'palabras': repartir(frase, ini, fin)})
    return sanear(lineas), off


# ---------------------------------------------------------------- de oído (si no hay letra oficial)

def agrupar(palabras, max_pal=7, hueco=0.9, max_seg=5.0):
    palabras = sorted(palabras, key=lambda w: w['ini'])
    lineas, act = [], []
    for w in palabras:
        if act:
            corta = (w['ini'] - act[-1]['fin'] > hueco or len(act) >= max_pal
                     or w['fin'] - act[0]['ini'] > max_seg or re.search(r'[.!?;,]$', act[-1]['t']))
            if corta:
                lineas.append(act)
                act = []
        act.append(w)
    if act:
        lineas.append(act)
    return sanear([{'ini': l[0]['ini'], 'fin': l[-1]['fin'], 'palabras': l} for l in lineas])


def sanear(lineas):
    """Frases en orden, sin solaparse y con palabras dentro de su frase."""
    lineas = sorted([l for l in lineas if l['palabras']], key=lambda l: l['ini'])
    limpio, fin_ant = [], -1.0
    for l in lineas:
        ini = max(l['ini'], fin_ant + 0.05)
        fin = max(l['fin'], ini + 0.3)
        ws, t = [], ini
        for w in sorted(l['palabras'], key=lambda w: w['ini']):
            a = min(max(w['ini'], t), fin - 0.05)
            b = min(max(w['fin'], a + 0.08), fin)
            ws.append({'t': w['t'], 'ini': round(a, 2), 'fin': round(b, 2)})
            t = b
        limpio.append({'ini': round(ini, 2), 'fin': round(fin, 2), 'palabras': ws})
        fin_ant = fin
    return limpio
